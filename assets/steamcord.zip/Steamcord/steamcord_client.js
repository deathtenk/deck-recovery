// Detect host: Vesktop (native Electron Discord — mic works) vs Steam's hidden CEF
// BrowserView (mic broken). In Vesktop we must NOT hijack getUserMedia / visibility,
// or we'd break the native mic. The CEF-only workarounds are guarded by !IS_VESKTOP.
// The backend sets window.STEAMCORD_IS_VESKTOP = true before this script when it
// injects into Vesktop (most reliable). Fall back to runtime detection otherwise.
window.STEAMCORD_IS_VESKTOP = window.STEAMCORD_IS_VESKTOP
    || !!window.VesktopNative
    || (navigator.userAgent || "").toLowerCase().includes("vesktop");

// ── Description lisible d'un échec de commande ───────────────────────────────
// `String(e)` ne convient QUE pour une Error. Un rejet de `RestAPI` n'en est
// pas une : c'est un objet {status, body:{message, code}} et `String()` en tire
// "[object Object]" — sondé le 24/07 en tentant d'éditer un message inexistant,
// où le motif rendu était littéralement "[object Object]". Aussi inutile que
// l'ancien silence : c'est le cas RÉEL que rencontre un utilisateur (le mien,
// simulé avec `new Error`, ne le montrait pas). On extrait donc le motif Discord
// (`body.message`, code, statut HTTP) avant de se rabattre sur une sérialisation.
window.__sc_describeError = (e) => {
    if (e == null) return "unknown error";
    if (typeof e === "string") return e;
    const parts = [];
    if (e.message) parts.push(String(e.message));
    const b = e.body;
    if (b && typeof b === "object") {
        if (b.message && b.message !== e.message) parts.push(String(b.message));
        if (b.code !== undefined) parts.push("code " + b.code);
    } else if (typeof b === "string" && b) {
        parts.push(b);
    }
    if (e.status !== undefined) parts.push("HTTP " + e.status);
    if (!parts.length) {
        try {
            const j = JSON.stringify(e);
            if (j && j !== "{}") parts.push(j.slice(0, 300));
        } catch (_) { /* structure cyclique : on se rabat sur String() */ }
    }
    return parts.join(" — ") || String(e);
};

// ── Titre de jeu → clé comparable entre Steam et Discord (issue #32) ─────────
// Steam garde les symboles légaux et la ponctuation typographique dans ses
// titres, la base des jeux détectables de Discord ne les a pas : "HELLDIVERS™ 2"
// vs "HELLDIVERS 2", "Marvel’s Spider-Man Remastered" (U+2019) vs "Marvel's …"
// (U+0027). Sans ça le titre ne se résout en aucun app id, et c'est l'app id qui
// porte l'artwork → activité affichée sans image.
// ⚠️ Les symboles partent AVANT le NFKC : la normalisation Unicode traduit ™ en
// "TM" (et ® en "(R)"), ce qui rendrait le titre encore plus faux.
window.rpcNormName = (s) => String(s)
    .replace(/[™®©]/g, "")      // symboles légaux
    .normalize("NFKC")          // demi-largeur, ligatures, etc.
    .replace(/[‘’ʼ]/g, "'")     // apostrophes typographiques
    .replace(/[“”]/g, '"')      // guillemets typographiques
    .replace(/[‐-―]/g, "-")     // tirets typographiques
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

// Dernier recours : lettres et chiffres seulement. Steam et Discord ponctuent
// différemment au-delà des symboles — "Resident Evil 7 Biohazard" vs "Resident
// Evil 7: Biohazard", "DmC Devil May Cry" vs "DmC: Devil May Cry" — un deux-points
// de trop suffit à perdre l'artwork.
// ⚠️ Cette clé-là est DANGEREUSE et n'est utilisable que filtrée : elle réduit
// tout titre entièrement non-latin (japonais, coréen, cyrillique, chinois) à la
// chaîne VIDE — mesuré sur la base réelle : 50+ jeux tombaient dans le même
// panier, chacun aurait hérité de l'image d'un autre. D'où les gardes posées à
// la construction de l'index (longueur, présence de lettres, unicité).
window.rpcNormNameLoose = (s) => String(s)
    .replace(/[™®©]/g, "")
    .normalize("NFKD")
    .replace(/\p{M}/gu, "")                       // accents décomposés
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");

// ── Mapping message Discord → forme attendue par le frontend QAM ─────────────
// Partagé entre $get_messages (chargement/pagination) et l'intercepteur Flux
// MESSAGE_CREATE/UPDATE (push temps réel du salon suivi) — même forme des deux
// côtés, sinon un message poussé en direct n'aurait pas le même rendu qu'un
// message chargé.
window.__sc_isImg = (a) => (a?.content_type || "").startsWith("image/")
    || /\.(png|jpe?g|gif|webp|bmp|avif)$/i.test(a?.filename || a?.url || "");
window.__sc_mapMsg = (m) => {
    const isImg = window.__sc_isImg;
    const atts = Array.isArray(m.attachments) ? m.attachments : [];
    // Images = pièces jointes image + images d'embeds (liens d'images
    // postés deviennent des embeds). proxy_url = CDN média redimensionnable.
    const images = [];
    for (const a of atts) {
        if (isImg(a)) images.push({ url: a.url, proxy_url: a.proxy_url || a.url, w: a.width || 0, h: a.height || 0 });
    }
    for (const e of (Array.isArray(m.embeds) ? m.embeds : [])) {
        const im = e?.image || e?.thumbnail;
        if (im && im.url) images.push({ url: im.url, proxy_url: im.proxy_url || im.url, w: im.width || 0, h: im.height || 0 });
    }
    // Réactions : uniquement les emojis Unicode standards pour l'instant (pas
    // les emojis custom du serveur — il faudrait charger la liste des emojis
    // de la guilde pour les afficher, hors scope). `emoji.id` non-null =
    // emoji custom → ignoré.
    const reactions = (Array.isArray(m.reactions) ? m.reactions : [])
        .filter(r => !r.emoji?.id)
        .map(r => ({ emoji: r.emoji?.name || "", count: r.count || 0, me: !!r.me }));
    // Contexte de citation si CE message est une réponse. Discord résout
    // `referenced_message` en même temps que le message qui répond (null si
    // le message cité a été supprimé depuis).
    const ref = m.referenced_message;
    const reply_to = ref ? {
        author: ref.author?.global_name || ref.author?.username || "?",
        content: (ref.content || "").slice(0, 80),
    } : null;
    return {
        id: String(m.id),
        author: m.author?.global_name || m.author?.username || "?",
        author_id: String(m.author?.id || ""),
        avatar: m.author?.avatar || null,
        bot: !!m.author?.bot,
        content: m.content ?? "",
        ts: m.timestamp || null,
        images,
        files: atts.filter(a => !isImg(a)).length,
        reactions,
        reply_to,
        _hasBody: !!(m.content) || images.length > 0 || atts.length > 0,
    };
};

// CEF only: override Page Visibility API so Discord audio/WebRTC stays active in a
// hidden BrowserView (Chrome throttles background tabs). Not needed in Vesktop.
if (!window.STEAMCORD_IS_VESKTOP) try {
    Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
    Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
    const _origAEL = document.addEventListener.bind(document);
    document.addEventListener = (type, handler, opts) => {
        if (type === 'visibilitychange') return;
        return _origAEL(type, handler, opts);
    };
} catch(_) {}

// ── Auto-validation de la modale Vesktop de partage d'écran ─────────────────
// Le Go Live NATIF (getDisplayMedia → setDisplayMediaRequestHandler de Vesktop)
// ouvre la modale qualité/audio de Vesktop DANS la fenêtre Discord cachée :
// personne ne peut la cliquer → le handler main-process attendrait à jamais et
// le partage resterait bloqué. On la valide automatiquement : 1) audio système
// via venmic (équivalent du choix « Entire System » de la modale), 2) clic sur
// « Go Live ». Observateur PERMANENT (pas lié à $golive) : la modale peut
// apparaître pour tout démarrage de stream. Qualité préréglée 1080p60 via
// VesktopState si l'utilisateur n'a jamais rien choisi (la patch screenShareFixes
// de Vesktop applique ces contraintes sur la piste vidéo).
if (window.STEAMCORD_IS_VESKTOP && !window.STEAMCORD_PICKER_WATCHER) {
    try {
        // `window.localStorage` est SUPPRIMÉ par Discord sur discord.com (mesure
        // anti-vol de jeton) : la lecture jetait, le catch avalait, et ce
        // préréglage pouvait n'être jamais posé. On passe par le localStorage
        // d'une iframe de même origine — le contournement qu'utilise Vencord.
        // Le réglage exposé dans le QAM (issue #33) écrit au même endroit.
        const _f = document.createElement("iframe");
        document.body.append(_f);
        const _ls = _f.contentWindow.localStorage;
        const st = JSON.parse(_ls.getItem("VesktopState") || "{}");
        if (!st.screenshareQuality) {
            st.screenshareQuality = { resolution: "1080", frameRate: "60" };
            _ls.setItem("VesktopState", JSON.stringify(st));
        }
        _f.remove();
    } catch (_) {}
    // Un el.click() ne suffit PLUS : depuis que les boutons de la modale sont
    // ceux du design system Discord (`data-mana-component`), le handler n'est pas
    // branché sur l'événement DOM — le clic partait dans le vide et la modale
    // restait ouverte (issue #42). On appelle onClick des props React, avec repli
    // sur le clic DOM pour les boutons Vencord (`vc-btn-*`, versions antérieures).
    const scReactClick = (el) => {
        const k = Object.keys(el).find((n) => n.startsWith("__reactProps"));
        const onClick = k && el[k] && el[k].onClick;
        if (typeof onClick === "function") {
            onClick({ preventDefault() {}, stopPropagation() {}, currentTarget: el, target: el, type: "click" });
            return "react";
        }
        el.click();
        return "dom";
    };
    window.STEAMCORD_PICKER_WATCHER = setInterval(async () => {
        try {
            // GATE : on n'auto-valide QUE les partages initiés par Steamcord
            // ($golive du QAM — flag posé par le handler). Un partage lancé À LA
            // MAIN dans la fenêtre Vesktop (mode bureau) garde sa modale : sans
            // ce gate, le clic auto validait le choix de l'utilisateur en 500 ms
            // (audio système imposé, qualité non choisie).
            if (!window.STEAMCORD_GOLIVE_ACTIVE) return;
            // La modale ne se repère PLUS par .vcd-screen-picker-footer : Vesktop
            // a déplacé Cancel/Go Live dans les `actions` de la modale Discord et
            // ce conteneur a disparu du rendu (la classe ne survit que dans le CSS
            // mort). Le sélecteur ne trouvait donc plus rien, la modale n'était
            // jamais validée et getDisplayMedia pendait jusqu'au watchdog — Go Live
            // mort pour tout le monde en mode jeu (issue #42). On s'ancre sur ce qui
            // reste à nous — un descendant .vcd-screen-picker-* — puis on remonte à
            // la modale. TOUTES, pas la première : à un stop→start rapproché la
            // modale précédente peut encore être dans le DOM (déjà validée,
            // scAuto=1) et la NOUVELLE ne serait jamais traitée (issue #12).
            const dlg = Array.from(document.querySelectorAll("[class*='vcd-screen-picker']"))
                .map((el) => el.closest("[role=dialog]"))
                .find((d) => d && !d.dataset.scAuto);
            if (!dlg) return;
            const buttons = Array.from(dlg.querySelectorAll("button"));
            const btn = buttons.find((b) => !b.disabled && /go live/i.test(b.textContent || ""));
            if (!btn) {
                // Première étape du sélecteur (grille de sources) : Go Live reste
                // désactivé tant qu'aucun écran n'est choisi. En mode jeu le portail
                // n'expose qu'une source et cette étape est sautée, mais le bureau
                // multi-écrans la montre. On prend la première source et on repassera
                // au tick suivant, quand Go Live sera actif.
                const screen = dlg.querySelector("[class*='vcd-screen-picker-screen']");
                if (screen) scReactClick(screen);
                return;
            }
            dlg.dataset.scAuto = "1";
            // venmic AVANT le clic : le device "vencord-screen-share" doit exister
            // quand screenShareFixes attache l'audio au stream. Échec toléré
            // (venmic absent/pipewire KO) → partage vidéo seule.
            try { await window.VesktopNative?.virtmic?.startSystem?.([]); } catch (_) {}
            const how = scReactClick(btn);
            console.log("[Steamcord] modale Vesktop de partage auto-validée (" + how + ", audio système via venmic)");
            // Même canal de diagnostic que $golive (scdiag y est local) : sans
            // cette ligne, un échec d'auto-validation reste invisible dans le log
            // backend — le seul artefact qu'un utilisateur peut nous envoyer.
            try { window.STEAMCORD_WS.send(JSON.stringify({ type: "$diag", m: "[golive] modale de partage auto-validée (" + how + ")" })); } catch (_) {}
        } catch (_) {}
    }, 500);
}

window.Vencord.Plugins.plugins.Steamcord = {
    name: "Steamcord",
    description: "Plugin required for Steamcord to work",
    authors: [],
    required: true,
    startAt: "DOMContentLoaded",
    async start() {
        // Garde anti-double-wrap : Vesktop survit aux restarts plugin_loader, donc
        // initialize() ré-injecte ce client plusieurs fois. Sans cette garde, la 2e
        // injection prend le wrapper de la 1re comme "old_" → le wrapper finit par
        // s'appeler lui-même → récursion infinie (Maximum call stack size exceeded,
        // crashait enableScreenCamera dès enumerateDevices). On ne wrappe qu'UNE fois
        // et on .bind() pour garder le bon `this` (sinon "Illegal invocation").
        if (!window.old_enumerate_devices) {
            window.old_enumerate_devices = navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices)
            navigator.mediaDevices.enumerateDevices = async () => {
                const devices = await window.old_enumerate_devices();
                // "vencord-screen-share" est le device venmic : c'est la sortie
                // système destinée au STREAM, jamais une entrée micro. Tant qu'il
                // restait énumérable, Discord pouvait le prendre pour micro et
                // renvoyer le salon dans le salon (larsen, 31/08). Le retirer ici
                // n'empêche pas Vesktop de s'en servir : screenShareFixes l'ouvre
                // par deviceId exact, sans passer par enumerateDevices.
                return devices.filter(f => f.label != "Filter Chain Source" && f.label != "Virtual Source" && f.label != "vencord-screen-share" && !(f.label == "" && f.deviceId == "default"))
            }
        }

        // Camera support (later): when a real webcam is plugged in, set
        // window.STEAMCORD_CAMERA_ENABLED = true and Discord's camera requests
        // (getUserMedia with video) will use the real device instead of the mic relay.
        // Screenshare uses getDisplayMedia (see webrtc_client.js), not this path.
        // Idem enumerateDevices : ne capturer le getUserMedia NATIF qu'une seule fois.
        // Sinon une ré-injection capture notre propre wrapper (steamcordGUM) comme
        // "old_" → récursion infinie quand le wrapper rappelle old_get_user_media.
        if (!window.old_get_user_media) {
            window.old_get_user_media = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
        }
        window.STEAMCORD_CAMERA_ENABLED = window.STEAMCORD_CAMERA_ENABLED ?? false;
        const steamcordGUM = (constraints) => new Promise(async (resolve, reject) => {
            console.log("[Steamcord] getUserMedia CALLED constraints=" + JSON.stringify(constraints) +
                " by: " + (new Error().stack || "").split("\n").slice(1, 4).join(" || "));
            if (window.STEAMCORD_CAMERA_ENABLED && constraints && constraints.video) {
                console.log("[Steamcord] Camera requested — using real device");
                return resolve(await window.old_get_user_media.call(navigator.mediaDevices, constraints));
            }
            if (window.MIC_STREAM != undefined && window.MIC_PEER_CONNECTION != undefined && window.MIC_PEER_CONNECTION.connectionState == "connected") {
                console.log("WebRTC stream available. Returning that.");
                return resolve(window.MIC_STREAM);
            }

            console.log("Starting WebRTC handshake for mic stream");
            const peerConnection = new RTCPeerConnection(null);
            window.MIC_PEER_CONNECTION = peerConnection;

            window.STEAMCORD_WS.addEventListener("message", async (e) => {
                const data = JSON.parse(e.data);
                if (data.type != "$webrtc") return;

                const remoteDescription = new RTCSessionDescription(data.payload);
                await peerConnection.setRemoteDescription(remoteDescription);
                console.log("[Steamcord] mic: answer set, connection negotiating");
            });

            peerConnection.ontrack = (ev) => {
                ev.track.stop = () => { console.log("CALLED STOP ON TRACK") }
                window.MIC_STREAM = new MediaStream([ev.track]);
                console.log("[Steamcord] mic: WEBRTC STREAM (ontrack)", window.MIC_STREAM);
                resolve(window.MIC_STREAM);
            }

            const offer = await peerConnection.createOffer({ offerToReceiveVideo: false, offerToReceiveAudio: true });
            await peerConnection.setLocalDescription(offer);
            // Non-trickle ICE: wait until candidates are gathered so they're embedded
            // in the SDP (localhost host candidates gather instantly). This avoids
            // routing ICE messages between the hidden tab and SharedJSContext.
            await new Promise((res) => {
                if (peerConnection.iceGatheringState === "complete") return res();
                const cb = () => {
                    if (peerConnection.iceGatheringState === "complete") {
                        peerConnection.removeEventListener("icegatheringstatechange", cb);
                        res();
                    }
                };
                peerConnection.addEventListener("icegatheringstatechange", cb);
                setTimeout(res, 2000);
            });
            console.log("[Steamcord] mic: sending offer to backend");
            window.STEAMCORD_WS.send(JSON.stringify({ type: "$MIC_WEBRTC", offer: peerConnection.localDescription }));
        });

        // ── Partage d'écran via CAMÉRA virtuelle (contournement gamescope) ──────────
        // En mode jeu, gamescope n'a PAS de portail → getDisplayMedia (Go Live) = noir.
        // À la place : gst_camera.py capture le node PipeWire gamescope → /dev/video42
        // (v4l2loopback "Steamcord Screen"). Ici on sélectionne cette caméra et on
        // active la vidéo dans le salon vocal. getUserMedia(video) renverra le vrai
        // device (STEAMCORD_CAMERA_ENABLED=true → branche "real device" plus haut).
        window.STEAMCORD_enableScreenCamera = async (on) => {
            const log = (m) => { try { window.STEAMCORD_WS.send(JSON.stringify({ type: "$diag", m: "[cam] " + m })); } catch (_) {} };
            try {
                const WP = Vencord.Webpack;
                if (!on) {
                    window.STEAMCORD_CAMERA_ENABLED = false;
                    try {
                        // Même lookup que le chemin d'activation (findByProps). Ne PAS
                        // utiliser findByCode("setVideoEnabled") : ça peut renvoyer un
                        // hook React → appelé hors render = "Minified React error #321".
                        const va = WP.findByProps?.("setVideoEnabled");
                        if (va?.setVideoEnabled) { va.setVideoEnabled(false); log("caméra coupée"); }
                        else log("setVideoEnabled introuvable (off)");
                    } catch (e) { log("off err " + e); }
                    return;
                }
                window.STEAMCORD_CAMERA_ENABLED = true;
                // 1) Trouver notre device par label. Le feeder gstcam met ~1-3s à
                // établir le pipeline + le lecteur keepalive qui fait passer le
                // device en CAPTURE (donc énumérable par Chromium). On RÉESSAIE
                // l'énumération jusqu'à ~12s avant d'abandonner, sinon on perd la
                // course (videoinputs=[] alors que le device arrive juste après).
                let cam = null;
                for (let attempt = 0; attempt < 12; attempt++) {
                    const devs = await navigator.mediaDevices.enumerateDevices();
                    const vins = devs.filter(d => d.kind === "videoinput");
                    cam = vins.find(d => /steamcord screen/i.test(d.label));
                    if (cam) {
                        log("videoinputs=" + JSON.stringify(vins.map(d => d.label || "(label vide)")) + " (essai " + attempt + ")");
                        break;
                    }
                    if (attempt === 0 || attempt === 11) {
                        log("videoinputs=" + JSON.stringify(vins.map(d => d.label || "(label vide)")) + " — pas encore 'Steamcord Screen' (essai " + attempt + ")");
                    }
                    await new Promise(r => setTimeout(r, 1000));
                }
                if (!cam) { log("AUCUN 'Steamcord Screen' après 12s — le feeder gstcam n'a pas fait passer /dev/video42 en CAPTURE (lecteur keepalive ?)"); return; }
                log("device choisi: " + JSON.stringify(cam.label) + " id=" + cam.deviceId.slice(0, 12));
                // 2) Sélectionner le device vidéo dans Discord. Ces actions renvoient
                // des PROMESSES : sans await, une rejection est silencieuse et on
                // loggait « OK » alors que la caméra ne s'activait jamais (test
                // 02/07 : setVideoEnabled(true) OK mais is_video jamais true).
                try {
                    const va = WP.findByProps?.("setVideoDevice");
                    if (va?.setVideoDevice) {
                        log("module setVideoDevice: " + Object.keys(va).slice(0, 12).join(","));
                        await Promise.resolve(va.setVideoDevice(cam.deviceId));
                        log("setVideoDevice OK");
                    } else log("setVideoDevice introuvable");
                } catch (e) { log("setVideoDevice REJETÉ " + e); }
                // 3) Activer la caméra dans le salon vocal courant.
                try {
                    const selCh = WP.findStore?.("SelectedChannelStore");
                    const vcId = selCh?.getVoiceChannelId?.();
                    if (!vcId) { log("pas dans un vocal — la cam s'activera au prochain appel"); }
                    const va = WP.findByProps?.("setVideoEnabled");
                    if (va?.setVideoEnabled) {
                        log("module setVideoEnabled: " + Object.keys(va).slice(0, 12).join(","));
                        await Promise.resolve(va.setVideoEnabled(true));
                        log("setVideoEnabled(true) OK (promesse résolue)");
                    } else log("setVideoEnabled introuvable");
                } catch (e) { log("setVideoEnabled REJETÉ " + e); }
                // 4) VERDICT : seul l'état gateway self_video prouve que les autres
                // reçoivent la vidéo (l'engine peut dire oui sans que rien parte).
                // Si toujours off à 2,5s, secours = re-appeler setVideoEnabled(true)
                // (le module d'actions média), puis re-verdict. L'ancien secours
                // cherchait `toggleSelfVideo` : sondé au CDP le 2026-07-19, ce
                // module n'existe plus dans le webpack Discord (ni byProps ni
                // byCode) — le log disait « introuvable » à chaque fois. Côté
                // engine, l'API est isVideoEnabled()/getVideoToggleState()
                // (isSelfVideoEnabled n'a jamais existé → undefined).
                const verdict = (label) => {
                    try {
                        const meId = WP.findStore?.("UserStore")?.getCurrentUser?.()?.id;
                        const vc2 = WP.findStore?.("SelectedChannelStore")?.getVoiceChannelId?.();
                        const states = WP.findStore?.("VoiceStateStore")?.getVoiceStatesForChannel?.(vc2) || {};
                        const st = meId ? states[meId] : null;
                        const MES = WP.findStore?.("MediaEngineStore");
                        const engOn = MES?.isVideoEnabled?.();
                        const on = st ? !!st.selfVideo : null;
                        log(label + " selfVideo(gateway)=" + on + " video(engine)=" + engOn
                            + " toggleState=" + MES?.getVideoToggleState?.());
                        return on;
                    } catch (e) { log(label + " err " + e); return null; }
                };
                setTimeout(() => {
                    if (verdict("VERDICT@2.5s:") === true) return;
                    try {
                        const va2 = WP.findByProps?.("setVideoEnabled");
                        if (va2?.setVideoEnabled) {
                            log("secours: re-setVideoEnabled(true)");
                            Promise.resolve(va2.setVideoEnabled(true)).catch((e) => log("secours setVideoEnabled REJETÉ " + e));
                        } else log("secours: setVideoEnabled introuvable");
                    } catch (e) { log("secours err " + e); }
                    setTimeout(() => verdict("VERDICT@5s:"), 2500);
                }, 2500);
            } catch (e) { log("FATAL " + e); }
        };

        // ── Relais vidéo INVERSE (Vesktop → QAM) ────────────────────────────────
        // Pour VOIR le Go Live/cam d'un participant dans le panneau QAM : on regarde
        // son stream (Discord décode + rend un <video>), on capture sa piste vidéo et
        // on l'OFFRE au QAM par WebRTC local — miroir du relais micro, sens inverse.
        // L'audio n'est PAS relayé : il est déjà audible via la sortie de Vesktop.
        // Corrélation par userId. findByCode (≠ id de module) survit aux MAJ Discord.
        window.STEAMCORD_VIDEO = window.STEAMCORD_VIDEO || {}; // userId -> { pc, streamKey }

        // Streams visibles d'un salon = UNION de deux registres du store (issue #8) :
        // « active streams » (les nôtres / déjà regardés — les seuls peuplés en appel
        // 1:1, ce que le code utilisait partout) et « application streams » (registre
        // gateway STREAM_CREATE/DELETE : contient AUSSI les streams des autres en
        // salon de serveur/groupe et les re-partages, invisibles côté active tant
        // qu'on ne les regarde pas). Dédupliqué par clé, l'entrée active (porteuse
        // de state) gagne.
        // Pistes vidéo ENTRANTES d'un utilisateur, lues sur le moteur média (issue #8).
        // Helper global : sert au relais, et se sonde en direct via CDP pendant un
        // vrai appel — c'est comme ça que l'association ci-dessous a été établie.
        window.__sc_videoTracksFor = (userId) => {
            const out = [];
            const seen = new Set();
            let eng = null;
            try { eng = Vencord.Webpack.findStore("MediaEngineStore").getMediaEngine(); } catch (e) { return out; }
            if (!eng || !eng.connections) return out;
            // `c.pc` sur le build actuel, mais les noms sont minifiés et changent d'une
            // version de Discord à l'autre → on reconnaît l'objet à son interface.
            const findPc = (c) => {
                if (c.pc && typeof c.pc.getReceivers === "function") return c.pc;
                for (const k of Object.keys(c)) {
                    const v = c[k];
                    if (v && typeof v === "object" && typeof v.getReceivers === "function") return v;
                }
                return null;
            };
            for (const c of [...eng.connections]) {
                const pc = findPc(c);
                if (!pc) continue;
                const isScreen = c.context === "stream" && c.streamUserId === userId;
                const isVoice = c.context === "default";
                if (!isScreen && !isVoice) continue;
                for (const r of pc.getReceivers()) {
                    const t = r.track;
                    // Les transceivers pré-alloués sont là mais muted : les écarter.
                    if (!t || t.kind !== "video" || t.muted || t.readyState !== "live") continue;
                    if (seen.has(t.id)) continue;
                    if (isScreen) { seen.add(t.id); out.push({ t, kind: "screen" }); continue; }
                    const owner = (c.trackUserIds || {})[t.id];
                    if (owner === userId) { seen.add(t.id); out.push({ t, kind: "camera" }); }
                }
            }
            // Ordre déterministe (écran d'abord), plus aucun tri par taille.
            out.sort((a, b) => (a.kind === "screen" ? 0 : 1) - (b.kind === "screen" ? 0 : 1));
            return out;
        };

        // Discord ne fait suivre que la vidéo des participants que SON UI affiche :
        // chaque tuile <video> tient un refcount de « sink actif » par streamId, et
        // à zéro le RTCMediaSinkWantsManager marque le user offscreen (LRU de 3 +
        // timeout) puis envoie wants=0 au serveur vocal → la piste caméra reçue
        // passe muted pour de bon → tuile noire (retours David #8 : bascule
        // cam1→cam2, cam+écran relancé ; l'appel 1:1 a un chemin spécial, d'où
        // « avec un seul flux tout marche »). Les Go Live passent par le
        // GoLiveQualityManager qui ne coupe jamais → seules les CAMÉRAS sont
        // touchées. Le relais se déclare donc lui-même comme sink actif (nom
        // "steamcord", à côté de celui de l'UI) pour le streamId de la caméra du
        // user relayé — l'exact équivalent d'une tuile montée.
        window.__sc_heldSinks = window.__sc_heldSinks || {}; // userId -> Set(streamId)
        window.__sc_cameraStreamId = (userId) => {
            try {
                const rc = Vencord.Webpack.findStore("RTCConnectionStore").getRTCConnection?.();
                return rc?._localMediaSinkWantsManager?.streamIds?.[userId] ?? null;
            } catch (e) { return null; }
        };
        window.__sc_holdSinks = (userId) => {
            const held = window.__sc_heldSinks[userId] || new Set();
            const want = new Set();
            const sid = window.__sc_cameraStreamId(userId);
            if (sid != null) want.add(sid);
            let eng = null;
            try { eng = Vencord.Webpack.findStore("MediaEngineStore").getMediaEngine(); } catch (e) { return; }
            if (!eng || !eng.connections) return;
            for (const c of [...eng.connections]) {
                if (typeof c.setHasActiveVideoOutputSink !== "function") continue;
                // Ré-affirmé à chaque tick : une connexion recréée (reconnexion,
                // re-partage) repart avec un registre de sinks vide.
                for (const s of want) { try { c.setHasActiveVideoOutputSink(s, true, "steamcord"); } catch (e) {} }
                // Caméra coupée/rallumée = nouveau streamId : lâcher l'ancien.
                for (const s of held) { if (!want.has(s)) { try { c.setHasActiveVideoOutputSink(s, false, "steamcord"); } catch (e) {} } }
            }
            window.__sc_heldSinks[userId] = want;
        };
        window.__sc_releaseSinks = (userId) => {
            const held = window.__sc_heldSinks[userId];
            delete window.__sc_heldSinks[userId];
            if (!held || !held.size) return;
            try {
                const eng = Vencord.Webpack.findStore("MediaEngineStore").getMediaEngine();
                for (const c of [...(eng && eng.connections || [])]) {
                    if (typeof c.setHasActiveVideoOutputSink !== "function") continue;
                    for (const s of held) { try { c.setHasActiveVideoOutputSink(s, false, "steamcord"); } catch (e) {} }
                }
            } catch (e) {}
        };

        window.__sc_streamsForChannel = (chId) => {
            const ASS = Vencord.Webpack.findStore("ApplicationStreamingStore");
            if (!ASS || !chId) return [];
            const keyOf = (s) => {
                const owner = s.ownerId || s.userId;
                return s.guildId ? `guild:${s.guildId}:${s.channelId}:${owner}` : `call:${s.channelId}:${owner}`;
            };
            const out = new Map();
            // Le registre « actif » GARDE une entrée state:"ENDED" pour un stream
            // qu'on regardait et que son proprio a coupé (observé en live, QAM
            // gardait la tuile) : un stream terminé n'est pas un stream.
            for (const s of (ASS.getAllActiveStreamsForChannel?.(chId) || [])) {
                if (s.state !== "ENDED") out.set(keyOf(s), s);
            }
            for (const s of (ASS.getAllApplicationStreamsForChannel?.(chId) || [])) {
                const k = keyOf(s);
                if (!out.has(k)) out.set(k, s);
            }
            // MON stream : getCurrentUserActiveStream est la vérité pour soi —
            // les listes par-channel le perdent TRANSITOIREMENT à la ré-ouverture
            // (issue #12 : badge LIVE + aperçu disparaissaient au stop→start
            // rapproché, le STOP synthétique débouncé partait alors que le
            // stream re-démarrait). L'union ici stabilise le badge.
            const own = ASS.getCurrentUserActiveStream?.();
            if (own && own.channelId === chId && own.state !== "ENDED") {
                const k = keyOf(own);
                if (!out.has(k)) out.set(k, own);
            }
            // 3e source, AUTORITATIVE : les voice states (issue #24). Les deux
            // registres ci-dessus dépendent de ce que la gateway a bien voulu nous
            // pousser — vérifié en live : un participant avec selfStream=true peut
            // être TOTALEMENT absent des deux (salon dont on n'a pas reçu les
            // STREAM_CREATE), et en appel DM « actif » ne contient QUE le stream
            // qu'on regarde. Résultat côté user : un seul ami affiché comme LIVE,
            // les autres sans badge ni bouton « Voir ». selfStream, lui, est
            // exactement ce que l'UI Discord utilise pour son propre badge.
            // Le stream reconstruit porte le strict nécessaire pour la clé, le
            // badge et STREAM_WATCH ({ownerId, channelId, guildId}).
            try {
                const VSS = Vencord.Webpack.findStore("VoiceStateStore");
                const guildId = Vencord.Webpack.findStore("ChannelStore")?.getChannel?.(chId)?.guild_id || null;
                const states = VSS?.getVoiceStatesForChannel?.(chId) || {};
                for (const uid in states) {
                    if (!states[uid] || !states[uid].selfStream) continue;
                    const s = { ownerId: uid, userId: uid, channelId: chId, guildId,
                                state: "ACTIVE", __sc_fromVoiceState: true };
                    const k = keyOf(s);
                    if (!out.has(k)) out.set(k, s);
                }
            } catch (e) { /* store indispo → on garde ce que la gateway a donné */ }
            return Array.from(out, ([key, s]) => ({ key, s }));
        };

        window.STEAMCORD_startVideoRelay = async (userId) => {
            try {
                const WP = Vencord.Webpack;
                const ASS = WP.findStore("ApplicationStreamingStore");
                const SCS = WP.findStore("SelectedChannelStore");
                const chId = SCS.getVoiceChannelId();

                // Deux cas : (a) GO LIVE = un stream actif (ApplicationStreamingStore)
                // qu'il faut WATCH pour s'abonner ; (b) CAMÉRA = pas de stream, Discord
                // rend déjà la cam du participant dans la tuile vocale → on capte
                // directement (pas de STREAM_WATCH, pas de streamKey).
                const entry = window.__sc_streamsForChannel(chId).find(e => (e.s.ownerId || e.s.userId) === userId);
                const s = entry && entry.s;
                let streamKey = null;
                if (s) {
                    streamKey = entry.key;
                    // Regarder le stream (s'abonner) — SEULEMENT si pas déjà viewer, car
                    // re-dispatcher STREAM_WATCH re-render le tile et tue la piste captée.
                    const myId = WP.findStore("UserStore").getCurrentUser()?.id;
                    const alreadyViewing = (ASS.getViewerIds?.(streamKey) || []).includes(myId);
                    if (!alreadyViewing) {
                        const watch = WP.findByCode('"STREAM_WATCH",streamKey');
                        // forceMultiple : sans lui, Discord décide tout seul s'il
                        // autorise plusieurs visionnages en comptant les streams de
                        // getAllActiveStreamsForChannel — un registre qui, justement,
                        // est souvent vide chez nous (issue #24). Le compte tombait
                        // donc sous 2, allowMultiple passait à false, et regarder le
                        // 2e partage COUPAIT le 1er : c'est le « ça a switché » du
                        // rapport. On le force, puisqu'on sait, nous, qu'on relaie
                        // plusieurs POV. noFocus : ne pas déplacer la sélection de
                        // l'UI Discord sous les pieds de l'utilisateur.
                        if (watch) watch(s, { forceMultiple: true, noFocus: true });
                        else console.warn("[Steamcord] video: action STREAM_WATCH introuvable");
                    }
                } else {
                    console.log("[Steamcord] video: pas de stream → cas CAMÉRA pour " + userId);
                }

                // SOURCE DES PISTES : le moteur média, PAS le DOM (issue #8).
                //
                // L'ancienne version capturait les <video> rendus (captureStream) en les
                // triant par TAILLE, faute de savoir quel élément appartenait à quel flux.
                // Deux problèmes, tous deux observés en vrai sur un appel :
                //   1. deux vidéos rendues = recopie (le fameux « miroir »), et l'ordre
                //      par taille est une devinette qui se trompe (une caméra de
                //      téléphone peut être plus grande qu'un partage d'écran) ;
                //   2. surtout, Discord NE REND QUE CE QU'IL AFFICHE : avec caméra ET
                //      partage actifs (selfVideo + selfStream à true), le DOM ne
                //      contenait qu'UN SEUL <video>. Un flux non affiché est donc
                //      impossible à relayer — aucun tri ne pouvait corriger ça.
                //
                // On lit donc les pistes entrantes directement sur les RTCPeerConnection
                // du moteur média, ce qui ne dépend plus du rendu. Association vérifiée
                // en live (voir issue #8) :
                //   • partage d'écran de X = piste sur la connexion context "stream"
                //     dont streamUserId === X ;
                //   • caméra de X = piste sur la connexion "default" (le vocal), le
                //     propriétaire venant de connection.trackUserIds (trackId → userId).
                // Les transceivers pré-alloués sont muted → on ne garde que live+unmuted.
                //
                // ⚠️ NE PAS se fier à participantOnScreen.userVideo pour distinguer
                // caméra/écran : c'est un attribut du PARTICIPANT (« cette personne a sa
                // caméra allumée »), pas de l'élément — vérifié en live, la même piste
                // passe de true à false quand la personne coupe sa caméra.
                const engineTracks = () => window.__sc_videoTracksFor(userId);
                // Attendre TOUTES les pistes ATTENDUES, pas la première venue : au
                // (re-)watch d'un Go Live la caméra est déjà là alors que l'écran
                // n'arrive qu'après l'aller-retour STREAM_WATCH → sortir à la 1re
                // piste = offre caméra seule, l'écran arrivé ensuite n'est jamais
                // ajouté (pas de renégociation). Bug trouvé par le user au 1er test
                // QAM (couper puis remettre cam+écran → plus que la caméra).
                const expected = new Set();
                if (s) expected.add("screen");
                try {
                    const vs = Object.values(WP.findStore("VoiceStateStore").getVoiceStatesForChannel(chId) || {});
                    if (vs.some(v => v.userId === userId && v.selfVideo)) expected.add("camera");
                } catch (e) { /* store indispo → on prend ce qui vient */ }
                // Tenir le sink AVANT d'attendre les pistes : une caméra déjà
                // coupée par wants=0 (tuile noire) existe mais est MUTED, donc
                // invisible pour engineTracks — la souscription doit repartir
                // d'abord pour que la piste se ranime pendant l'attente.
                window.__sc_holdSinks(userId);
                let found = [];
                for (let i = 0; i < 80; i++) {
                    found = engineTracks();
                    const kinds = new Set(found.map(x => x.kind));
                    if (found.length && [...expected].every(k => kinds.has(k))) break;
                    await new Promise(r => setTimeout(r, 100));
                }
                const tracks = found.map(x => x.t);
                if (found.length) console.log("[Steamcord] video: " + found.map(x => x.kind).join("+") + " pour " + userId + " (attendu: " + [...expected].join("+") + ")");
                if (!tracks.length) { console.warn("[Steamcord] video: piste introuvable pour " + userId); window.__sc_releaseSinks(userId); return; }

                // Fermer un éventuel relais précédent pour ce user avant d'en recréer un.
                const prev = window.STEAMCORD_VIDEO[userId];
                if (prev) { try { prev.pc && prev.pc.close(); } catch {} if (prev.keepalive) clearInterval(prev.keepalive); }

                const pc = new RTCPeerConnection(null);
                const senders = tracks.map(t => pc.addTrack(t));

                // Keepalive : une piste du moteur meurt quand la personne coupe puis
                // relance son partage (nouvelle piste, nouvel id) → on remplace sans
                // renégocier. Contrairement à l'ancienne capture DOM, un simple
                // re-render de Discord ne tue plus la piste : ce filet ne sert donc
                // plus qu'aux vraies coupures.
                // Le remplacement se fait PAR SORTE (écran→écran, caméra→caméra),
                // JAMAIS par index : au retour d'un partage la seule piste fraîche
                // peut être la caméra, et un mapping par index la collait sur le
                // sender de l'ÉCRAN (miroir réinventé — trouvé au 1er test QAM).
                // Si l'ensemble des SORTES change (caméra allumée en cours de route,
                // écran revenu alors que son sender a été abandonné), l'offre est
                // figée (pas de renégociation) → on RECONSTRUIT le relais entier.
                const kinds = found.map(x => x.kind);
                let staleMisses = 0;
                const restart = (why) => {
                    clearInterval(keepalive);
                    const cur = window.STEAMCORD_VIDEO[userId];
                    if (cur && cur.pc === pc) {
                        console.log("[Steamcord] video: reconstruction du relais (" + why + ") pour " + userId);
                        window.STEAMCORD_startVideoRelay(userId);
                    }
                };
                const keepalive = setInterval(() => {
                    try {
                        if (pc.connectionState === "closed") { clearInterval(keepalive); return; }
                        // Souscription caméra ré-affirmée en continu (connexion
                        // recréée, caméra rallumée = nouveau streamId…).
                        window.__sc_holdSinks(userId);
                        const fresh = engineTracks();
                        // nouvelle sorte de piste qu'aucun sender ne porte → rebuild.
                        if (fresh.some(f => !kinds.includes(f.kind))) { restart("nouvelle piste " + fresh.map(x => x.kind).join("+")); return; }
                        // « morte » = finie OU MUETTE : quand la personne coupe SA
                        // caméra, la piste reçue ne meurt pas, elle passe muted pour
                        // toujours (observé en live : sender "live" figé). Le délai de
                        // 8 s absorbe les mutes transitoires (réseau, keyframe).
                        const gone = (tk) => !tk || tk.readyState === "ended" || tk.muted;
                        const deadIdx = senders.map((sn, i) => gone(sn.track) ? i : -1).filter(i => i >= 0);
                        if (!deadIdx.length) { staleMisses = 0; return; }
                        const used = new Set(senders.filter(sn => !gone(sn.track)).map(sn => sn.track.id));
                        let replaced = 0;
                        for (const i of deadIdx) {
                            const f = fresh.find(x => x.kind === kinds[i] && !used.has(x.t.id));
                            if (f) { used.add(f.t.id); senders[i].replaceTrack(f.t); replaced++; console.log("[Steamcord] video: piste " + kinds[i] + " remplacée (keepalive) pour " + userId); }
                        }
                        // sender mort sans remplaçant de sa sorte pendant ~8 s :
                        // • s'il RESTE des pistes (partage coupé, caméra gardée) →
                        //   rebuild sans la sorte disparue (la tuile morte s'en va) ;
                        // • s'il ne reste RIEN (tout coupé) → arrêt PROPRE du relais
                        //   (pc + STREAM_CLOSE + entrée), sinon il tournait pour
                        //   toujours avec une image figée (observé en live).
                        if (replaced < deadIdx.length) {
                            if (++staleMisses >= 8) {
                                if (fresh.length) restart("piste " + kinds[deadIdx[0]] + " disparue");
                                else { clearInterval(keepalive); window.STEAMCORD_stopVideoRelay(userId); }
                            }
                        } else { staleMisses = 0; }
                    } catch (e) { /* ignore */ }
                }, 1000);
                window.STEAMCORD_VIDEO[userId] = { pc, streamKey, keepalive };

                const offer = await pc.createOffer();
                await pc.setLocalDescription(offer);
                await new Promise((res) => {
                    if (pc.iceGatheringState === "complete") return res();
                    const cb = () => { if (pc.iceGatheringState === "complete") { pc.removeEventListener("icegatheringstatechange", cb); res(); } };
                    pc.addEventListener("icegatheringstatechange", cb);
                    setTimeout(res, 2000);
                });
                // meta : dit au QAM quelle ligne m= est l'ÉCRAN et laquelle est la
                // CAMÉRA (corrélation par mid, stable dans le SDP). Sans ça le front
                // affiche des tuiles anonymes — et ne peut pas proposer « plein écran
                // sur l'écran » vs « sur la caméra » (retour David, issue #8).
                const kindByTrackId = Object.fromEntries(found.map(x => [x.t.id, x.kind]));
                const meta = pc.getTransceivers()
                    .filter(tr => tr.sender && tr.sender.track)
                    .map(tr => ({ mid: tr.mid, kind: kindByTrackId[tr.sender.track.id] || "video" }));
                window.STEAMCORD_WS.send(JSON.stringify({ type: "$VIDEO_WEBRTC", userId, offer: pc.localDescription, meta }));
                console.log("[Steamcord] video: offer envoyée pour " + userId);
            } catch (e) {
                console.error("[Steamcord] video relay start failed", e);
                // Pas de relais monté → personne ne libérera les sinks tenus plus haut.
                if (!window.STEAMCORD_VIDEO[userId]) window.__sc_releaseSinks(userId);
            }
        };

        window.STEAMCORD_stopVideoRelay = (userId) => {
            try {
                const entry = window.STEAMCORD_VIDEO[userId];
                if (!entry) return;
                window.__sc_releaseSinks(userId);
                if (entry.keepalive) clearInterval(entry.keepalive);
                if (entry.pc) entry.pc.close();
                const close = Vencord.Webpack.findByCode('"STREAM_CLOSE",streamKey');
                if (close && entry.streamKey) close(entry.streamKey);
                delete window.STEAMCORD_VIDEO[userId];
                console.log("[Steamcord] video: relais arrêté pour " + userId);
            } catch (e) { console.error("[Steamcord] video relay stop failed", e); }
        };

        // ── Relais POV pour l'overlay in-game (H264/fMP4 → MSE) ──────────────
        // L'overlay tourne dans WebKitGTK : PAS de WebRTC, et son MSE NE DÉCODE
        // PAS le WebM/VP8 de MediaRecorder (sondé : démuxé mais jamais lu) —
        // MAIS il DÉCODE le H264/MP4 fragmenté (sondé : readyState 3, lecture
        // fluide). Donc : ICI (Chromium/Vesktop) on encode la piste en
        // `video/mp4;codecs=avc1` avec MediaRecorder (vrai flux 30 fps, décodage
        // matériel/logiciel efficace, contrairement au motion-JPEG) et on pousse
        // les fragments par le WS local ; le backend les relaie à l'overlay qui
        // les lit en MSE. Le 1er fragment (init : ftyp+moov) est marqué `init`
        // et mis en cache backend pour tout consommateur qui se connecte après.
        // Un encodeur par user relayé ; piste préférée = écran, sinon caméra.
        window.STEAMCORD_POV = window.STEAMCORD_POV || {}; // userId -> entry

        window.STEAMCORD_startPov = (userId) => {
            if (window.STEAMCORD_POV[userId]) return;
            const entry = { alive: true, streamKey: null, rec: null, kind: null };
            window.STEAMCORD_POV[userId] = entry;

            const acquire = async () => {
                // Go Live : il faut s'ABONNER (STREAM_WATCH) pour que la piste
                // écran arrive — même démarche que le relais WebRTC du QAM.
                try {
                    const WP = Vencord.Webpack;
                    const chId = WP.findStore("SelectedChannelStore").getVoiceChannelId();
                    const e2 = window.__sc_streamsForChannel(chId).find(x => (x.s.ownerId || x.s.userId) === userId);
                    if (e2) {
                        entry.streamKey = e2.key;
                        const myId = WP.findStore("UserStore").getCurrentUser()?.id;
                        const ASS = WP.findStore("ApplicationStreamingStore");
                        if (!(ASS.getViewerIds?.(e2.key) || []).includes(myId)) {
                            const watch = WP.findByCode('"STREAM_WATCH",streamKey');
                            if (watch) watch(e2.s);
                        }
                    }
                } catch (e) { /* pas de stream → cas caméra */ }
                window.__sc_holdSinks(userId);
                for (let i = 0; i < 50 && entry.alive; i++) {
                    const found = window.__sc_videoTracksFor(userId);
                    if (found.length) return found.find(x => x.kind === "screen") || found[0];
                    await new Promise(r => setTimeout(r, 200));
                }
                return null;
            };

            (async () => {
                while (entry.alive) {
                    const sel = await acquire();
                    if (!sel || !entry.alive) break;
                    const track = sel.t;
                    entry.kind = sel.kind;
                    let rec;
                    try {
                        rec = new MediaRecorder(new MediaStream([track]),
                            { mimeType: 'video/mp4;codecs=avc1.42E01E', videoBitsPerSecond: 2500000 });
                    } catch (e) { console.error("[Steamcord] pov: MediaRecorder KO", e); break; }
                    entry.rec = rec;
                    let seq = 0;
                    const stopped = new Promise((r) => { rec.onstop = r; rec.onerror = r; });
                    rec.ondataavailable = async (ev2) => {
                        if (!ev2.data || !ev2.data.size) return;
                        try {
                            const buf = new Uint8Array(await ev2.data.arrayBuffer());
                            let bin = ""; const CH = 0x8000;
                            for (let i = 0; i < buf.length; i += CH)
                                bin += String.fromCharCode.apply(null, buf.subarray(i, i + CH));
                            window.STEAMCORD_WS.send(JSON.stringify({
                                type: "$pov_chunk", userId, kind: entry.kind,
                                init: seq === 0, data: btoa(bin),
                            }));
                            seq++;
                        } catch (e) { /* WS fermé : reprise au prochain start */ }
                    };
                    // timeslice court = faible latence (fragments fMP4 ~120 ms).
                    rec.start(120);
                    console.log("[Steamcord] pov: encodeur H264 " + sel.kind + " démarré pour " + userId);
                    // Surveille la piste : morte (partage coupé) ou mutée
                    // (caméra éteinte) → on stoppe et l'acquire suivant
                    // re-sélectionne (nouveau fragment d'init pour l'overlay).
                    while (entry.alive && track.readyState === "live" && !track.muted) {
                        await new Promise(r => setTimeout(r, 1000));
                        window.__sc_holdSinks(userId);
                    }
                    try { if (rec.state !== "inactive") rec.stop(); } catch (e) {}
                    await stopped;
                    if (!entry.alive) break;
                    await new Promise(r => setTimeout(r, 300));
                }
                delete window.STEAMCORD_POV[userId];
                console.log("[Steamcord] pov: arrêté pour " + userId);
            })();
        };

        window.STEAMCORD_stopPov = (userId) => {
            const entry = window.STEAMCORD_POV[userId];
            if (!entry) return;
            entry.alive = false;
            try { if (entry.rec && entry.rec.state !== "inactive") entry.rec.stop(); } catch (e) {}
            // Ne fermer le stream Go Live / lâcher les sinks caméra que si le
            // relais WebRTC du QAM ne regarde pas AUSSI ce user (sinon on lui
            // couperait l'image sous le pied).
            if (!window.STEAMCORD_VIDEO[userId]) {
                window.__sc_releaseSinks(userId);
                try {
                    const close = Vencord.Webpack.findByCode('"STREAM_CLOSE",streamKey');
                    if (close && entry.streamKey) close(entry.streamKey);
                } catch (e) {}
            }
        };

        // Discord's MediaEngine reinitializes and OVERWRITES our getUserMedia override,
        // so it ends up calling the native one and capturing a silent CEF device →
        // nobody hears the user. Install our override resiliently (defineProperty with a
        // no-op setter) on both the instance and the prototype, and re-assert it.
        function installMicOverride() {
            const desc = { configurable: true, get: () => steamcordGUM, set: () => {} };
            try { Object.defineProperty(navigator.mediaDevices, "getUserMedia", desc); }
            catch (e) { try { navigator.mediaDevices.getUserMedia = steamcordGUM; } catch (_) {} }
            try { Object.defineProperty(MediaDevices.prototype, "getUserMedia", desc); } catch (_) {}
        }
        // CEF only: in Vesktop the native mic works, so installing this override would
        // hijack/break it. Never install it under Vesktop.
        if (!window.STEAMCORD_IS_VESKTOP) {
            installMicOverride();
            setInterval(installMicOverride, 2000);
        }

        function dataURLtoFile(dataurl, filename) {
            var arr = dataurl.split(','),
                mime = arr[0].match(/:(.*?);/)[1],
                bstr = atob(arr[arr.length - 1]),
                n = bstr.length,
                u8arr = new Uint8Array(n);
            while (n--) {
                u8arr[n] = bstr.charCodeAt(n);
            }
            return new File([u8arr], filename, { type: mime });
        }

        // Issue #36 — clavier virtuel : ceci était un setInterval(100 ms) qui
        // cherchait la zone de saisie et ne s'arrêtait QU'EN CAS DE SUCCÈS.
        // Sur toute vue sans zone de saisie (liste d'amis, salon vocal, forum,
        // boutique…) `[0]` vaut undefined, l'affectation jette, le catch avale,
        // et clearInterval n'est JAMAIS atteint : la boucle interroge le DOM
        // entier 10 fois par seconde, pour toujours. Pire, patchTypingField()
        // est rappelée à CHAQUE CHANNEL_SELECT — une boucle fuitée de plus par
        // salon sans zone de saisie visité, cumulées sur toute la session.
        // Mesuré au CDP sur une simple liste d'amis : 10 querySelectorAll/s en
        // continu, seule requête DOM répétée de tout le renderer.
        // Remplacé par UN écouteur délégué posé une fois : zéro sondage, et il
        // couvre aussi les zones de saisie créées après coup.
        let typingFieldHooked = false;
        function patchTypingField() {
            if (typingFieldHooked) return;
            typingFieldHooked = true;
            document.addEventListener("click", (e) => {
                try {
                    const t = e.target;
                    if (t && t.closest && t.closest("[role=\"textbox\"]"))
                        fetch("http://127.0.0.1:65123/openkb", { mode: "no-cors" });
                } catch (err) { }
            }, true);
        }

        // Le statut Discord (online/idle/dnd/invisible) vit dans le settings proto
        // "PreloadedUserSettings" (type 1), pas dans un action-creator updateStatus
        // (qui n'existe plus). On localise le proto store dont getCurrentValue()
        // expose .status, puis on mute via updateAsync("status", ...).
        let _statusProtoStore;
        function getStatusProtoStore() {
            if (_statusProtoStore) return _statusProtoStore;
            try {
                const cache = Vencord.Webpack.wreq && Vencord.Webpack.wreq.c;
                if (!cache) return null;
                const test = (m) => {
                    try {
                        if (m && typeof m.updateAsync === "function" && m.type === 1 &&
                            typeof m.getCurrentValue === "function" && m.getCurrentValue().status) return m;
                    } catch (e) { }
                    return null;
                };
                for (const id in cache) {
                    try {
                        const exp = cache[id] && cache[id].exports;
                        if (!exp) continue;
                        let s = test(exp);
                        if (!s && typeof exp === "object") {
                            for (const k in exp) { s = test(exp[k]); if (s) break; }
                        }
                        if (s) { _statusProtoStore = s; return s; }
                    } catch (e) { }
                }
            } catch (e) { }
            return null;
        }

        let CloudUpload;
        CloudUpload = Vencord.Webpack.findLazy(m => m.prototype?.trackUploadFinished);;
        function sendAttachmentToChannel(channelId, attachment_b64, filename) {
            const file = dataURLtoFile(`data:text/plain;base64,${attachment_b64}`, filename);
            return uploadFileToChannel(channelId, file);
        }

        // #40 : même téléversement, mais à partir d'un File déjà constitué. Une
        // vidéo ne peut pas passer par la websocket en base64 (un tiers de
        // volume en plus, sur la boucle qui sert aussi la voix) : le client va
        // la chercher en HTTP local et la remet ici.
        function uploadFileToChannel(channelId, file) {
            return new Promise((resolve, reject) => {
                const upload = new CloudUpload({
                    file: file,
                    isClip: false,
                    isThumbnail: false,
                    platform: 1,
                }, channelId, false, 0);
                upload.on("complete", () => {
                    Vencord.Webpack.Common.RestAPI.post({
                        url: `/channels/${channelId}/messages`,
                        body: {
                            channel_id: channelId,
                            content: "",
                            nonce: Vencord.Webpack.Common.SnowflakeUtils.fromTimestamp(Date.now()),
                            sticker_ids: [],
                            type: 0,
                            attachments: [{
                                id: "0",
                                filename: upload.filename,
                                uploaded_filename: upload.uploadedFilename
                            }]
                        }
                    });
                    resolve(true);
                });
                upload.on("error", () => resolve(false))
                upload.upload();
            })
        }

        let MediaEngineStore, FluxDispatcher;
        console.log("Steamcord: Waiting for FluxDispatcher...");
        Vencord.Webpack.waitFor(["subscribe", "dispatch", "register"], fdm => {
            FluxDispatcher = fdm;
            Vencord.Webpack.waitFor(Vencord.Webpack.filters.byStoreName("MediaEngineStore"), m => {
                MediaEngineStore = m;
                FluxDispatcher.dispatch({ type: "MEDIA_ENGINE_SET_AUDIO_ENABLED", enabled: true, unmute: true });
                // ROOT CAUSE of "nobody hears me": Discord's MediaEngine never enables mic
                // capture because the hidden tab never gets a user interaction
                // (engine.interacted stays false → engine.enabled stays false → no capture).
                // Force the interaction flag and enable the engine, and re-assert it since
                // Discord can reset it.
                const forceEngineEnabled = () => {
                    try {
                        const eng = m.getMediaEngine && m.getMediaEngine();
                        if (!eng) return;
                        eng.interacted = true;
                        if (typeof eng.setAudioEnabled === "function") eng.setAudioEnabled(true);
                        else if (typeof eng.enable === "function") eng.enable();
                    } catch (_) {}
                };
                // Also dispatch the DOM events Discord listens to for "interacted"
                try {
                    for (const type of ["pointerdown", "mousedown", "click", "keydown", "touchstart"])
                        document.dispatchEvent(new Event(type, { bubbles: true }));
                } catch (_) {}
                forceEngineEnabled();
                setInterval(forceEngineEnabled, 3000);
            });

            function connect() {
                // Garde anti-double-client : si un WS est déjà ouvert/en cours, ne pas
                // en créer un second (sinon chaque message backend est traité 2×).
                if (window.STEAMCORD_WS && window.STEAMCORD_WS.readyState <= 1) return;
                window.STEAMCORD_WS = new WebSocket('ws://127.0.0.1:65123/socket');
                window.STEAMCORD_WS.addEventListener("message", async function (e) {
                    const data = JSON.parse(e.data);
                    if (data.type.startsWith("$")) {
                        let result;
                        try {
                            switch (data.type) {
                                case "$getuser":
                                    result = Vencord.Webpack.Common.UserStore.getUser(data.id);
                                    break;
                                case "$getchannel":
                                    result = Vencord.Webpack.Common.ChannelStore.getChannel(data.id);
                                    break;
                                case "$getguild":
                                    result = Vencord.Webpack.Common.GuildStore.getGuild(data.id);
                                    break;
                                case "$getmedia":
                                    result = {
                                        mute: MediaEngineStore.isSelfMute(),
                                        deaf: MediaEngineStore.isSelfDeaf(),
                                        live: MediaEngineStore.getGoLiveSource() != undefined
                                    }
                                    break;
                                case "$get_last_channels":
                                    result = {}
                                    const ChannelStore = Vencord.Webpack.Common.ChannelStore;
                                    const GuildStore = Vencord.Webpack.Common.GuildStore;
                                    const channelIds = Object.values(JSON.parse(Vencord.Util.localStorage.SelectedChannelStore).mostRecentSelectedTextChannelIds);
                                    for (const chId of channelIds) {
                                        const ch = ChannelStore.getChannel(chId);
                                        const guild = GuildStore.getGuild(ch.guild_id);
                                        result[chId] = `${ch.name} (${guild.name})`;
                                    }
                                    break;
                                case "$get_screen_bounds":
                                    result = { width: screen.width, height: screen.height }
                                    break;
                                // Vérité de Discord sur un partage en cours. Le
                                // backend s'en sert AVANT de redémarrer Vesktop
                                // pour libérer une capture orpheline : son propre
                                // `is_live` peut se désynchroniser (vu le 31/08,
                                // le QAM restait bloqué sur « Arrêter le Go Live »
                                // pour un stream disparu). Se fier à lui seul
                                // risquerait de TUER un partage bien vivant.
                                case "$get_active_stream": {
                                    let st = null;
                                    try {
                                        st = Vencord.Webpack.findStore("ApplicationStreamingStore")
                                                ?.getCurrentUserActiveStream?.() || null;
                                    } catch (_) { st = null; }
                                    result = { active: !!st, state: st?.state ?? null };
                                    break;
                                }
                                case "$ptt":
                                    try {
                                        MediaEngineStore.getMediaEngine().connections.values().next().value.setForceAudioInput(data.value);
                                    } catch (error) { }
                                    return;
                                case "$setptt":
                                    FluxDispatcher.dispatch({
                                        "type": "AUDIO_SET_MODE",
                                        "context": "default",
                                        "mode": data.enabled ? "PUSH_TO_TALK" : "VOICE_ACTIVITY",
                                        "options": MediaEngineStore.getSettings().modeOptions
                                    });
                                    return;
                                case "$clip": {
                                    // Le backend ne pousse qu'un JETON et une URL locale ;
                                    // il ne nous laisse jamais désigner un chemin, sinon
                                    // n'importe quel fichier du disque serait lisible.
                                    try {
                                        const r = await fetch(data.url);
                                        if (!r.ok) throw new Error("HTTP " + r.status);
                                        const blob = await r.blob();
                                        const file = new File([blob], data.filename,
                                            { type: blob.type || "video/mp4" });
                                        const ok = await uploadFileToChannel(data.channel_id, file);
                                        window.STEAMCORD_WS.send(JSON.stringify({
                                            type: "$diag",
                                            m: "[clip] " + data.filename + " (" + blob.size + " o) → " + (ok ? "envoyé" : "refusé par Discord")
                                        }));
                                    } catch (e) {
                                        window.STEAMCORD_WS.send(JSON.stringify({
                                            type: "$diag", m: "[clip] échec : " + (e && e.message ? e.message : e)
                                        }));
                                    }
                                    return;
                                }
                                case "$screenshot":
                                    result = await sendAttachmentToChannel(data.channel_id, data.attachment_b64, "screenshot.jpg");
                                    break;
                                case "$set_user_volume": {
                                    // context "default" = voix, "stream" = audio du Go Live (volumes indépendants).
                                    // Le moteur stocke une AMPLITUDE ; l'UI Discord affiche un volume
                                    // PERCEPTUEL (conversion du module webpack 792251). Le QAM parle
                                    // perceptuel pour coller aux % Discord — sans ça le défaut stream
                                    // (amplitude 18 = 54 % perçus) s'affichait « 18 % ».
                                    const p = Number(data.volume) || 0;
                                    const amp = p === 0 ? 0 : (p < 100 ? Math.pow(p / 100, 2.8) : Math.pow(10, (p / 100 - 1) * 6 / 20)) * 100;
                                    FluxDispatcher.dispatch({ type: "AUDIO_SET_LOCAL_VOLUME", userId: data.id, volume: amp, context: data.context || "default" });
                                    return;
                                }
                                case "$get_user_volume": {
                                    // Vérité moteur pour les sliders du QAM : sans relecture au
                                    // montage ils retombaient à 100 % à chaque réouverture alors
                                    // que le moteur gardait p. ex. 150 % (issue #5). Amplitude
                                    // moteur → perceptuel (voir $set_user_volume).
                                    const MES = Vencord.Webpack.findStore("MediaEngineStore");
                                    const a = MES?.getLocalVolume ? MES.getLocalVolume(data.id, data.context || "default") : 100;
                                    result = a === 0 ? 0 : (a < 100 ? Math.pow(a / 100, 1 / 2.8) : (20 * Math.log10(a / 100) / 6 + 1)) * 100;
                                    break;
                                }
                                case "$get_local_mute": {
                                    // Mute LOCAL (côté client seulement : on ne les entend plus, eux ne le savent pas).
                                    const MES = Vencord.Webpack.findStore("MediaEngineStore");
                                    result = !!(MES && MES.isLocalMute && MES.isLocalMute(data.id));
                                    break;
                                }
                                case "$toggle_local_mute": {
                                    const mod = Vencord.Webpack.findByProps("toggleLocalMute");
                                    if (mod && mod.toggleLocalMute) mod.toggleLocalMute(data.id);
                                    const MES = Vencord.Webpack.findStore("MediaEngineStore");
                                    result = !!(MES && MES.isLocalMute && MES.isLocalMute(data.id)); // nouvel état
                                    break;
                                }
                                case "$set_local_mute": {
                                    // SET idempotent (≠ toggle aveugle) : on ne bascule que si l'état
                                    // courant diffère du voulu → un double-clic gamescope ne re-flip plus.
                                    const MES = Vencord.Webpack.findStore("MediaEngineStore");
                                    const cur = !!(MES && MES.isLocalMute && MES.isLocalMute(data.id));
                                    if (cur !== !!data.muted) {
                                        const mod = Vencord.Webpack.findByProps("toggleLocalMute");
                                        if (mod && mod.toggleLocalMute) mod.toggleLocalMute(data.id);
                                    }
                                    result = !!(MES && MES.isLocalMute && MES.isLocalMute(data.id));
                                    break;
                                }
                                case "$set_status": {
                                    // data.status: "online" | "idle" | "dnd" | "invisible"
                                    try {
                                        const store = getStatusProtoStore();
                                        if (store) {
                                            await store.updateAsync("status", (s) => { s.status.value = data.status; }, 0);
                                            console.log("[Steamcord] status → " + data.status);
                                        } else console.warn("[Steamcord] proto store status introuvable");
                                    } catch (e) { console.error("[Steamcord] set_status err", e); }
                                    return;
                                }
                                case "$get_status": {
                                    try {
                                        // Le proto store donne la vraie valeur réglée (y compris
                                        // "invisible", que PresenceStore rapporte comme "offline").
                                        const store = getStatusProtoStore();
                                        const protoStatus = store?.getCurrentValue?.()?.status?.status?.value;
                                        if (protoStatus) { result = { status: protoStatus }; break; }
                                        const me = Vencord.Webpack.Common.UserStore.getCurrentUser();
                                        const PS = Vencord.Webpack.findStore("PresenceStore");
                                        result = { status: PS?.getStatus?.(me.id) || "online" };
                                    } catch (e) { result = { status: "online" }; }
                                    break;
                                }
                                case "$golive": {
                                    // #42 : tout ce qui suit l'acquisition se passait dans la console
                                    // de Vesktop, inaccessible en mode jeu — un utilisateur dont le
                                    // Go Live échoue APRÈS la capture ne pouvait rien nous envoyer
                                    // d'exploitable. On trace les étapes vers le log backend.
                                    const scdiag = (m) => {
                                        try { window.STEAMCORD_WS.send(JSON.stringify({ type: "$diag", m: "[golive] " + m })); } catch (_) {}
                                    };
                                    const selChStore = Vencord.Webpack.findStore("SelectedChannelStore");
                                    const golive_channel_id = selChStore?.getVoiceChannelId?.();
                                    if (!golive_channel_id) {
                                        console.warn("[Steamcord] Go Live: pas dans un salon vocal");
                                        scdiag("abandon : pas dans un salon vocal");
                                        return;
                                    }
                                    const golive_channel = Vencord.Webpack.Common.ChannelStore.getChannel(golive_channel_id);
                                    const golive_guild_id = golive_channel?.guild_id ?? null;

                                    // L'ancienne API (modules m.startStream/m.stopStream) a DISPARU de
                                    // Discord. On utilise les action creators actuels via findByCode
                                    // (robuste aux changements d'ID de module) : STREAM_START / STREAM_STOP.
                                    // getDisplayMedia (webrtc_client.js) : portail NATIF d'abord — en
                                    // mode jeu c'est notre portal_shim.py qui sert le node gamescope,
                                    // la modale Vesktop est auto-validée (watcher ci-dessus) — puis
                                    // repli sur le relais GStreamer local. Aucun picker visible.
                                    const WP = Vencord.Webpack;
                                    try {
                                        if (data.stop) {
                                            // ⚠️ NE PAS éteindre STEAMCORD_GOLIVE_ACTIVE si une acquisition
                                            // est en vol : la modale Vesktop (invisible en gamemode) ne
                                            // serait jamais auto-cliquée → son callback main-process ne
                                            // répond jamais → TOUS les getDisplayMedia suivants pendent
                                            // (wedge Electron vécu le 19/07, seul un restart Vesktop le
                                            // libère). On laisse l'acquisition se terminer ; le chemin
                                            // START verra le drapeau stop et libérera la source.
                                            if (window.STEAMCORD_GOLIVE_PENDING) {
                                                window.STEAMCORD_GOLIVE_STOP_REQUESTED = true;
                                            } else {
                                                window.STEAMCORD_GOLIVE_ACTIVE = false;
                                            }
                                            const ASS = WP.findStore("ApplicationStreamingStore");
                                            const s = ASS?.getCurrentUserActiveStream?.();
                                            const stopFn = WP.findByCode('"STREAM_STOP"');
                                            if (s && stopFn) {
                                                const key = s.guildId
                                                    ? `guild:${s.guildId}:${s.channelId}:${s.ownerId}`
                                                    : `call:${s.channelId}:${s.ownerId}`;
                                                stopFn(key);
                                            }
                                            // Horodatage pour le chemin START : une ré-ouverture trop
                                            // rapide doit laisser le teardown (session portail, source
                                            // du pool, venmic) se finir avant de ré-acquérir (issue #12).
                                            // venmic doit mourir AVEC le partage. L'auto-validation le
                                            // démarre (`startSystem`) pour donner le son du jeu aux
                                            // spectateurs, mais rien ne l'arrêtait : le device
                                            // "vencord-screen-share" survivait au STOP, restait la seule
                                            // source audio RUNNING (steamcord_silence, lui, se met en
                                            // SUSPENDED) et finissait par servir de MICRO. L'utilisateur
                                            // renvoyait alors le son du salon dans le salon — l'autre
                                            // participante entendait un larsen ("bip bip bip"), stream
                                            // actif ou non. Signalé le 31/08, reproduit : une seule capture
                                            // vesktop, sur `vencord-screen-share`.
                                            try { await window.VesktopNative?.virtmic?.stop?.(); } catch (_) {}
                                            window.STEAMCORD_GOLIVE_LAST_STOP = Date.now();
                                            console.log("[Steamcord] Go Live STOP envoyé (venmic arrêté)");
                                        } else {
                                            // Autorise l'auto-validation de la modale Vesktop (watcher
                                            // en tête de fichier) pour CE partage initié par Steamcord.
                                            window.STEAMCORD_GOLIVE_ACTIVE = true;
                                            const startFn = WP.findByCode('"STREAM_START",streamType');
                                            if (!startFn) {
                                                window.STEAMCORD_GOLIVE_ACTIVE = false;
                                                console.warn("[Steamcord] Go Live: action STREAM_START introuvable");
                                                scdiag("abandon : action STREAM_START introuvable dans le bundle Discord");
                                                return;
                                            }
                                            // Bundle Discord ≥ 19/07/2026 : STREAM_START seul ne lance plus
                                            // AUCUNE capture — l'ApplicationSwitchingManager exige pid OU
                                            // sourceId (sinon warn « invalid start_stream ») et plus personne
                                            // n'acquiert la source → stream ACTIVE avec 0 sender vidéo =
                                            // écran noir chez les spectateurs (diagnostiqué au CDP : stats
                                            // outbound-rtp vides). On reproduit le flux navigateur de Discord
                                            // lui-même : eng.getDesktopSource() (= getDisplayMedia via le
                                            // DesktopInputPool → notre portail en gamemode, modale Vesktop
                                            // auto-validée) PUIS STREAM_START avec l'id du pool (le label de
                                            // la piste — souvent "" via le portail, clé de pool valide).
                                            // Prouvé au CDP 19/07 : sender attaché, ~55 fps encodés.
                                            // Garde anti-chevauchement : un 2e $golive pendant qu'une
                                            // acquisition est en vol (double-clic, backend+bouton) créerait
                                            // une 2e modale/2e session portail et peut coincer Electron.
                                            if (window.STEAMCORD_GOLIVE_PENDING) {
                                                console.log("[Steamcord] Go Live: acquisition déjà en cours, ignoré");
                                                return;
                                            }
                                            const eng = WP.findStore("MediaEngineStore")?.getMediaEngine?.();
                                            if (eng?.getDesktopSource) {
                                                window.STEAMCORD_GOLIVE_PENDING = true;
                                                window.STEAMCORD_GOLIVE_STOP_REQUESTED = false;
                                                const myGen = (window.STEAMCORD_GOLIVE_GEN = (window.STEAMCORD_GOLIVE_GEN || 0) + 1);
                                                try {
                                                    // Laisser le PARTAGE PRÉCÉDENT finir de se démonter avant
                                                    // de ré-acquérir (issue #12 : fermer puis rouvrir en <1s
                                                    // faisait se chevaucher teardown de session portail et
                                                    // nouvelle acquisition → getDisplayMedia coincé, bouton
                                                    // mort). On attend que le stream actif ait disparu du
                                                    // store ET ≥3,5s depuis le STOP, 9s max.
                                                    //
                                                    // 1,2s ne suffisaient pas (mesuré le 01/09) : à ce
                                                    // rythme, pw-dump était encore coincé par le churn du
                                                    // partage précédent et `Start` mettait 14s au lieu de
                                                    // 30ms — le budget du client sautait et le Go Live
                                                    // était perdu. Le bouton du QAM grise déjà 6s après un
                                                    // arrêt ; ce garde-fou couvre les autres chemins
                                                    // (raccourci manette, double appel du backend).
                                                    const ASS2 = WP.findStore("ApplicationStreamingStore");
                                                    const t0 = Date.now();
                                                    while (Date.now() - t0 < 9000) {
                                                        const busy = ASS2?.getCurrentUserActiveStream?.();
                                                        const sinceStop = Date.now() - (window.STEAMCORD_GOLIVE_LAST_STOP || 0);
                                                        if (!busy && sinceStop >= 3500) break;
                                                        if (window.STEAMCORD_GOLIVE_STOP_REQUESTED) break;
                                                        await new Promise(r => setTimeout(r, 200));
                                                    }
                                                    if (window.STEAMCORD_GOLIVE_STOP_REQUESTED) {
                                                        window.STEAMCORD_GOLIVE_ACTIVE = false;
                                                        console.log("[Steamcord] Go Live: annulé avant l'acquisition");
                                                        return;
                                                    }
                                                    // Watchdog : si l'acquisition pend (modale jamais apparue,
                                                    // handler main-process muet), on rend la main au lieu de
                                                    // laisser le bouton mort pour toujours ; si la promesse se
                                                    // résout tardivement, la garde de génération ci-dessous
                                                    // libère la source au lieu de démarrer un stream fantôme.
                                                    // 45s, PAS 20 : getDisplayMedia (webrtc_client.js) essaie le
                                                    // portail natif pendant 25s AVANT de se replier sur le relais
                                                    // GStreamer (~4s). À 20s ce watchdog tirait le premier, donc le
                                                    // repli n'a JAMAIS pu aboutir : la source arrivait après coup et
                                                    // se faisait libérer ici même. C'est la 2e moitié de #42 — le
                                                    // relais réparé en v1.28.3 négociait dans le vide.
                                                    const acqPromise = eng.getDesktopSource({ width: 1920, height: 1080 }, true);
                                                    // Résolution APRÈS timeout : source acquise pour rien →
                                                    // la libérer (sinon session portail qui fuit à chaque
                                                    // tentative coincée).
                                                    let raceSettled = false;
                                                    acqPromise.then((id) => {
                                                        if (!raceSettled) return;
                                                        try { eng.desktopInputPool?.get?.(id)?.destroy?.(); } catch (_) {}
                                                        console.log("[Steamcord] Go Live: acquisition résolue après timeout, source libérée");
                                                    }).catch(() => {});
                                                    let srcId;
                                                    try {
                                                        srcId = await Promise.race([
                                                            acqPromise,
                                                            new Promise((_, rej) => setTimeout(() => rej(new Error("getDesktopSource timeout (45s)")), 45000)),
                                                        ]);
                                                    } finally {
                                                        raceSettled = true;
                                                    }
                                                    if (window.STEAMCORD_GOLIVE_STOP_REQUESTED || myGen !== window.STEAMCORD_GOLIVE_GEN) {
                                                        // Stop arrivé pendant l'acquisition (ou tentative plus
                                                        // récente en cours) : on libère la source fraîchement
                                                        // acquise au lieu de démarrer.
                                                        if (myGen === window.STEAMCORD_GOLIVE_GEN) window.STEAMCORD_GOLIVE_ACTIVE = false;
                                                        try { eng.desktopInputPool?.get?.(srcId)?.destroy?.(); } catch (_) {}
                                                        console.log("[Steamcord] Go Live: annulé pendant l'acquisition, source libérée");
                                                    } else {
                                                        scdiag("source acquise (id=" + JSON.stringify(srcId) + ") guild="
                                                            + golive_guild_id + " channel=" + golive_channel_id + " → STREAM_START");
                                                        startFn(golive_guild_id, golive_channel_id, { pid: null, sourceId: srcId, sourceName: null });
                                                        console.log("[Steamcord] Go Live START envoyé (source pool: " + JSON.stringify(srcId) + ")");
                                                        // Le point aveugle de #42 : l'appel ne rend rien. La seule
                                                        // preuve qu'un stream EXISTE est le store, 2 s plus tard.
                                                        setTimeout(() => {
                                                            try {
                                                                const st = WP.findStore("ApplicationStreamingStore")?.getCurrentUserActiveStream?.();
                                                                scdiag(st ? ("stream publié : channel=" + st.channelId + " state=" + st.state)
                                                                          : "AUCUN stream dans le store 2 s après STREAM_START — Discord ne l'a pas créé");
                                                            } catch (e) { scdiag("relecture du store impossible: " + e); }
                                                        }, 2000);
                                                    }
                                                } catch (e) {
                                                    if (myGen === window.STEAMCORD_GOLIVE_GEN) window.STEAMCORD_GOLIVE_ACTIVE = false;
                                                    console.error("[Steamcord] Go Live: acquisition écran échouée:", e);
                                                    scdiag("échec avant/pendant l'acquisition : " + (e && e.message ? e.message : e));
                                                } finally {
                                                    if (myGen === window.STEAMCORD_GOLIVE_GEN) {
                                                        window.STEAMCORD_GOLIVE_PENDING = false;
                                                        window.STEAMCORD_GOLIVE_STOP_REQUESTED = false;
                                                    }
                                                }
                                            } else {
                                                // Vieux bundle sans pool exposé : l'ancien chemin suffisait.
                                                startFn(golive_guild_id, golive_channel_id, {});
                                                console.log("[Steamcord] Go Live START envoyé (flux legacy)");
                                            }
                                        }
                                    } catch (e) {
                                        console.error("[Steamcord] Go Live échec:", e);
                                        scdiag("exception : " + (e && e.message ? e.message : e));
                                    }
                                    return;
                                }
                                case "$screen_camera": {
                                    await window.STEAMCORD_enableScreenCamera?.(!data.stop);
                                    return;
                                }
                                case "$rpc": {
                                    // Rich Presence (issue #11) : le QAM envoie le jeu Steam en
                                    // cours (Router.MainRunningApp) — on le publie comme activité
                                    // « Playing … » via le même dispatch local que les plugins
                                    // Vencord (CustomRPC). game=null → activité effacée. Le
                                    // backend rejoue le dernier état à chaque (re)connexion,
                                    // started_at ne bouge pas → temps de jeu continu.
                                    // application_id est REQUIS par la validation du dispatch
                                    // (vérifié au CDP 19/07 : sans lui, LocalActivityStore reste
                                    // vide). On le résout dans la base des jeux détectables de
                                    // Discord (match insensible à la casse — l'exact-match de
                                    // Deckcord ratait des jeux), cache en mémoire ; introuvable
                                    // → "0" (l'activité s'affiche quand même, nom brut, mais
                                    // SANS artwork — c'est l'app id qui porte l'image).
                                    // Issue #32 : Steam et Discord n'écrivent pas les titres
                                    // pareil — Steam garde les symboles légaux et l'apostrophe
                                    // typographique ("HELLDIVERS™ 2", "DARK SOULS™ III",
                                    // "Marvel’s Spider-Man Remastered"), la base Discord ne les
                                    // a pas ("HELLDIVERS 2", "Marvel's …"). D'où un 2e index
                                    // normalisé, consulté seulement si le nom brut ne tombe pas
                                    // juste, puis un 3e index « lettres et chiffres seuls » pour
                                    // les écarts de ponctuation. Ordre strict du plus sûr au plus
                                    // permissif : le match exact reste prioritaire, donc aucun jeu
                                    // qui marchait déjà ne peut changer de cible.
                                    try {
                                        let appId = "0", rpcName = data.game;
                                        // Lanceurs connus : eux-mêmes détectables par Discord, donc
                                        // « Heroic » résout parfaitement... et masque le jeu. On ne
                                        // consulte les processus QUE pour eux, ou quand le nom n'a
                                        // rien résolu — un jeu Steam qui marche déjà ne peut donc
                                        // pas se faire remplacer par une app de fond détectable.
                                        const SC_LAUNCHERS = new Set(["heroic", "heroicgameslauncher",
                                            "lutris", "bottles", "playnite", "goggalaxy",
                                            "epicgameslauncher", "itch", "amazongames", "minigalaxy"]);
                                        if (data.game) {
                                            try {
                                                // On exige aussi le dernier index : après une mise
                                                // à jour du plugin, une page déjà ouverte a le
                                                // cache exact d'avant mais aucun des deux nouveaux
                                                // — sans ce test le correctif n'arriverait qu'au
                                                // prochain rechargement de Vesktop.
                                                if (!window.__sc_rpcAppIds || !window.__sc_rpcAppIdsLoose || !window.__sc_rpcExecs) {
                                                    const res = await Vencord.Webpack.Common.RestAPI.get({ url: "/applications/detectable" });
                                                    const map = new Map(), norm = new Map(), loose = new Map(), execs = new Map();
                                                    if (res.ok) for (const e of res.body) {
                                                        const n = String(e.name);
                                                        map.set(n.toLowerCase(), e.id);
                                                        // 1er inscrit gagne : la base contient des
                                                        // doublons de nom, on ne les réécrit pas.
                                                        const k = window.rpcNormName(n);
                                                        if (!norm.has(k)) norm.set(k, e.id);
                                                        // Index de dernier recours, sous conditions :
                                                        // au moins 6 caractères ET au moins une lettre
                                                        // (sinon les titres non-latins s'effondrent sur
                                                        // "" et les titres numériques sur "2"), et toute
                                                        // clé réclamée par deux applications distinctes
                                                        // est mise à null → plus jamais résolue. Mieux
                                                        // vaut aucune image que celle d'un autre jeu.
                                                        const l = window.rpcNormNameLoose(n);
                                                        if (l.length >= 6 && /[a-z]/.test(l)) {
                                                            if (!loose.has(l)) loose.set(l, e.id);
                                                            else if (loose.get(l) !== e.id) loose.set(l, null);
                                                        }
                                                        // #41 : la base Discord liste aussi les
                                                        // EXÉCUTABLES de chaque jeu — c'est par eux que
                                                        // le client officiel détecte ce qu'un lanceur a
                                                        // ouvert. On les indexe par nom de fichier seul
                                                        // (les entrées portent des chemins, win32 comme
                                                        // linux). On IGNORE celles marquées is_launcher :
                                                        // ce sont justement les lanceurs, les indexer
                                                        // reviendrait à réafficher Heroic. Comme pour
                                                        // l'index permissif, un exécutable réclamé par
                                                        // deux applications est mis à null — plutôt rien
                                                        // que le mauvais jeu.
                                                        for (const x of (e.executables || [])) {
                                                            if (x?.is_launcher) continue;
                                                            const b = String(x?.name || "")
                                                                .split(/[\\/]/).pop().toLowerCase();
                                                            if (!b) continue;
                                                            if (!execs.has(b)) execs.set(b, { id: e.id, name: n });
                                                            else if (execs.get(b)?.id !== e.id) execs.set(b, null);
                                                        }
                                                    }
                                                    window.__sc_rpcAppIds = map;
                                                    window.__sc_rpcAppIdsNorm = norm;
                                                    window.__sc_rpcAppIdsLoose = loose;
                                                    window.__sc_rpcExecs = execs;
                                                }
                                                const raw = String(data.game);
                                                appId = window.__sc_rpcAppIds.get(raw.toLowerCase())
                                                    || window.__sc_rpcAppIdsNorm?.get(window.rpcNormName(raw))
                                                    || window.__sc_rpcAppIdsLoose?.get(window.rpcNormNameLoose(raw))
                                                    || "0";
                                                // La liste arrive triée du plus récemment démarré au
                                                // plus ancien : le premier exécutable reconnu est le
                                                // jeu qu'on vient d'ouvrir, pas un résidu.
                                                // #41 : réglages utilisateur. Un titre imposé gagne sur
                                                // TOUT — c'est la seule réponse aux cas que la base de
                                                // Discord ne sait pas distinguer (toute la série Need for
                                                // Speed classique partage speed.exe, et Discord ne connaît
                                                // qu'un « Most Wanted »). L'interrupteur, lui, coupe la
                                                // substitution sans couper le Rich Presence.
                                                const forced = String(data.override || "").trim();
                                                if (forced) {
                                                    rpcName = forced;
                                                    appId = window.__sc_rpcAppIds.get(forced.toLowerCase())
                                                        || window.__sc_rpcAppIdsNorm?.get(window.rpcNormName(forced))
                                                        || window.__sc_rpcAppIdsLoose?.get(window.rpcNormNameLoose(forced))
                                                        || "0";
                                                }
                                                const isLauncher = SC_LAUNCHERS.has(window.rpcNormNameLoose(raw));
                                                if (!forced && data.detect !== false && (isLauncher || appId === "0")) {
                                                    const titleKey = window.rpcNormNameLoose(raw);
                                                    for (const proc of (data.procs || [])) {
                                                        const hit = window.__sc_rpcExecs?.get(String(proc).toLowerCase());
                                                        if (!hit || hit.id === appId) continue;
                                                        // Titre NON résolu : exiger que l'exécutable ait un
                                                        // rapport avec ce que Steam annonce. Sans ce test,
                                                        // n'importe quelle app détectable qui traîne en fond
                                                        // s'empare du statut — @imrprogamer a vu Harbor
                                                        // afficher la jaquette d'un autre programme (#41).
                                                        // Pas d'image valait mieux que la MAUVAISE image.
                                                        // Pour un LANCEUR, au contraire, on veut justement
                                                        // un jeu qui n'a rien à voir avec « Heroic ».
                                                        if (!isLauncher) {
                                                            const stem = window.rpcNormNameLoose(
                                                                String(proc).replace(/\.[^.]+$/, ""));
                                                            if (!stem || !titleKey) continue;
                                                            if (!titleKey.startsWith(stem) && !stem.startsWith(titleKey)
                                                                && !titleKey.includes(stem) && !stem.includes(titleKey)) continue;
                                                        }
                                                        appId = hit.id;
                                                        rpcName = hit.name;
                                                        break;
                                                    }
                                                }
                                            } catch (_) { /* hors-ligne/API KO : nom brut */ }
                                        }
                                        // Le backend re-émet périodiquement pour rattraper un jeu
                                        // lancé DEPUIS un lanceur (Steam ne nous en dit rien, #41).
                                        // On ne redispatche que si le résultat a VRAIMENT changé,
                                        // sinon on enverrait la même activité toutes les 20 s.
                                        const sig = data.game ? appId + "|" + rpcName : "";
                                        if (sig === window.__sc_lastRpcSig) return;
                                        window.__sc_lastRpcSig = sig;   // passé ici = la signature A changé
                                        // #41 : `started_at` du backend suit le titre STEAM, qui reste
                                        // « Heroic » du début à la fin. Le compteur ne repartait donc
                                        // jamais : en fermant son jeu, @imrprogamer voyait Heroic
                                        // reprendre le temps écoulé, puis le jeu suivant le continuer.
                                        // Quand c'est NOUS qui avons substitué le jeu, c'est le
                                        // changement de signature qui fait foi. Sinon on garde la date
                                        // du backend, qui elle survit à une reconnexion du client.
                                        const substituted = rpcName !== data.game;
                                        if (substituted) window.__sc_rpcStartedAt = Date.now();
                                        const startAt = substituted
                                            ? (window.__sc_rpcStartedAt || Date.now())
                                            : data.started_at;
                                        const activity = data.game ? {
                                            application_id: appId,
                                            name: rpcName,
                                            type: 0, // Playing
                                            flags: 1, // INSTANCE
                                            timestamps: startAt ? { start: startAt } : undefined,
                                        } : null;
                                        FluxDispatcher.dispatch({
                                            type: "LOCAL_ACTIVITY_UPDATE",
                                            socketId: "steamcord-rpc",
                                            activity,
                                        });
                                        console.log("[Steamcord] RPC → " + (data.game ? "Playing " + rpcName + " (app " + appId + ")" + (rpcName !== data.game ? " [processus ; Steam disait " + data.game + "]" : "") : "effacé"));
                                    } catch (e) {
                                        console.error("[Steamcord] RPC échec:", e);
                                    }
                                    return;
                                }
                                case "$get_dm_channels": {
                                    const CS = Vencord.Webpack.Common.ChannelStore;
                                    const US = Vencord.Webpack.Common.UserStore;
                                    const VSS = Vencord.Webpack.findStore?.("VoiceStateStore");
                                    const sorted = CS?.getSortedPrivateChannels?.() ?? [];
                                    result = sorted.slice(0, 30).map(ch => {
                                        // "Active" only if someone is actually connected to the call.
                                        // CallStore.getCall() lingers after a call ends → false "EN CALL".
                                        const states = VSS?.getVoiceStatesForChannel?.(ch.id) || {};
                                        const activeCall = Object.keys(states).length > 0;
                                        const recipientIds = Array.isArray(ch.recipientIDs) ? ch.recipientIDs
                                            : Array.isArray(ch.recipients) ? ch.recipients.map(r => typeof r === 'string' ? r : r.id)
                                            : [];
                                        const recipients = recipientIds.map(id => {
                                            const u = US?.getUser?.(id);
                                            return { id: String(id), username: u?.username ?? String(id), avatar: u?.avatar ?? null };
                                        });
                                        const name = ch.name || (recipients.length === 1 ? recipients[0].username : `Group (${recipients.length + 1})`);
                                        return {
                                            id: String(ch.id),
                                            type: ch.type ?? 1,
                                            name,
                                            icon: ch.icon ?? null,
                                            recipients,
                                            active_call: activeCall,
                                        };
                                    });
                                    break;
                                }
                                case "$dm_call": {
                                    const channelId = data.id;
                                    if (data.join_existing) {
                                        FluxDispatcher.dispatch({ type: "VOICE_CHANNEL_SELECT", channelId, guildId: null });
                                    } else {
                                        const CallActions = Vencord.Webpack.find(m => m && typeof m.startCall === 'function');
                                        if (CallActions) CallActions.startCall(channelId);
                                        else FluxDispatcher.dispatch({ type: "VOICE_CHANNEL_SELECT", channelId, guildId: null });
                                    }
                                    result = true;
                                    break;
                                }
                                case "$get_guilds_vc": {
                                    const GS = Vencord.Webpack.Common?.GuildStore;
                                    const GCS = Vencord.Webpack.findStore("GuildChannelStore");
                                    const SGS = Vencord.Webpack.findStore("SortedGuildStore");
                                    const VSS = Vencord.Webpack.findStore("VoiceStateStore");
                                    const US = Vencord.Webpack.Common?.UserStore;
                                    // #28 « Servers not loading, error python exception ». Vencord
                                    // résout ces stores PARESSEUSEMENT : dans les premières secondes
                                    // après un (re)démarrage de Discord ils valent encore undefined.
                                    // `Object.keys(GS.getGuilds())` était HORS du try/catch par
                                    // serveur plus bas → TypeError brut, relayé tel quel jusqu'au
                                    // QAM (« ça charge… puis erreur »). On échoue désormais avec un
                                    // code STABLE que le frontend traduit et qui déclenche un
                                    // réessai, au lieu d'exposer une exception crue.
                                    if (typeof GS?.getGuilds !== "function" || typeof GCS?.getChannels !== "function") {
                                        throw new Error("stores_not_ready");
                                    }
                                    const sortedIds = SGS?.getFlattenedGuildIds?.() ?? SGS?.getGuilds?.()?.map(g => g.id) ?? Object.keys(GS.getGuilds());
                                    const allGuilds = GS.getGuilds();
                                    result = [];
                                    for (const guildId of sortedIds) {
                                        const guild = allGuilds[guildId];
                                        if (!guild) continue;
                                        try {
                                            const gc = GCS.getChannels(guild.id);
                                            const vocalList = gc?.VOCAL || [];
                                            const vocal = vocalList
                                                .map(e => {
                                                    const chId = String(e.channel?.id ?? e.id ?? "");
                                                    const chName = String(e.channel?.name ?? e.name ?? "");
                                                    if (!chId || !chName) return null;
                                                    const states = VSS?.getVoiceStatesForChannel?.(chId) || {};
                                                    const members = Object.values(states).map(vs => {
                                                        const u = US?.getUser?.(vs.userId);
                                                        return { id: vs.userId, avatar: u?.avatar || null };
                                                    });
                                                    return { id: chId, name: chName, members };
                                                })
                                                .filter(Boolean);
                                            if (vocal.length > 0) result.push({ id: String(guild.id), name: String(guild.name), icon: guild.icon || null, channels: vocal });
                                        } catch (_) {}
                                    }
                                    break;
                                }
                                case "$join_vc":
                                    FluxDispatcher.dispatch({ type: "VOICE_CHANNEL_SELECT", channelId: data.id, guildId: data.guild_id });
                                    result = true;
                                    break;
                                case "$get_voice_states": {
                                    const vsStore = Vencord.Webpack.findStore("VoiceStateStore");
                                    const states = vsStore?.getVoiceStatesForChannel?.(data.id) || {};
                                    result = Object.values(states).map(vs => ({
                                        userId: vs.userId,
                                        mute: vs.mute || vs.selfMute || false,
                                        deaf: vs.deaf || vs.selfDeaf || false,
                                        video: vs.selfVideo || false,
                                    }));
                                    break;
                                }
                                case "$get_soundboard_sounds": {
                                    // Sons par défaut Discord + sons du serveur du salon vocal courant +
                                    // (si Nitro) sons de tous les autres serveurs rejoints — même perk que
                                    // le client officiel ("soundboard everywhere"), détecté ici via
                                    // premiumType plutôt qu'en rejouant leur logique interne de feature-flag.
                                    const SCS = Vencord.Webpack.findStore("SelectedChannelStore");
                                    const CS = Vencord.Webpack.Common.ChannelStore || Vencord.Webpack.findStore("ChannelStore");
                                    const GS = Vencord.Webpack.Common.GuildStore;
                                    const US = Vencord.Webpack.Common.UserStore;
                                    const vcId = SCS?.getVoiceChannelId?.();
                                    const vcChannel = vcId ? CS?.getChannel?.(vcId) : null;
                                    const currentGuildId = vcChannel?.guild_id || null;

                                    const mapSound = (s) => ({
                                        id: String(s.sound_id), name: String(s.name || ""),
                                        emoji: s.emoji_name || null, volume: s.volume ?? 1,
                                    });

                                    const out = { default: [], guild: null, everywhere: [] };
                                    try {
                                        const def = await Vencord.Webpack.Common.RestAPI.get({ url: "/soundboard-default-sounds" });
                                        out.default = (def?.body || []).map(mapSound);
                                    } catch (_) { }

                                    if (currentGuildId) {
                                        try {
                                            const g = await Vencord.Webpack.Common.RestAPI.get({ url: `/guilds/${currentGuildId}/soundboard-sounds` });
                                            const items = g?.body?.items || [];
                                            out.guild = { guildId: currentGuildId, guildName: GS?.getGuild?.(currentGuildId)?.name || "", sounds: items.map(mapSound) };
                                        } catch (_) { }
                                    }

                                    const premiumType = US?.getCurrentUser?.()?.premiumType;
                                    if (premiumType) {
                                        const allGuilds = GS?.getGuilds?.() || {};
                                        for (const gid of Object.keys(allGuilds)) {
                                            if (gid === currentGuildId) continue;
                                            try {
                                                const g = await Vencord.Webpack.Common.RestAPI.get({ url: `/guilds/${gid}/soundboard-sounds` });
                                                const items = g?.body?.items || [];
                                                if (items.length) out.everywhere.push({ guildId: gid, guildName: allGuilds[gid]?.name || "", sounds: items.map(mapSound) });
                                            } catch (_) { }
                                        }
                                    }
                                    result = out;
                                    break;
                                }
                                case "$play_soundboard_sound": {
                                    // Le son ne joue que dans le salon vocal où l'on est effectivement
                                    // connecté (comme le vrai client) ; source_guild_id seulement pour un
                                    // son venant d'un AUTRE serveur que celui du salon courant.
                                    const SCS2 = Vencord.Webpack.findStore("SelectedChannelStore");
                                    const channelId = SCS2?.getVoiceChannelId?.();
                                    if (!channelId) { result = { ok: false, error: "not_in_voice" }; break; }
                                    const body = { sound_id: data.soundId };
                                    if (data.sourceGuildId) body.source_guild_id = data.sourceGuildId;
                                    try {
                                        await Vencord.Webpack.Common.RestAPI.post({ url: `/channels/${channelId}/send-soundboard-sound`, body });
                                        // La requête REST ci-dessus notifie le serveur (les AUTRES participants
                                        // l'entendent) mais ne joue RIEN localement — le vrai client Discord
                                        // dispatche EN PLUS cette action pour se faire entendre soi-même
                                        // (retrouvé en lisant le code source de son bouton soundboard natif :
                                        // GUILD_SOUNDBOARD_SOUND_PLAY_LOCALLY). guildId "0" = son par défaut,
                                        // même convention que source_guild_id ci-dessus. Testé en vrai : joue
                                        // même avec un objet minimal (pas besoin du nom/emoji/volume).
                                        try {
                                            Vencord.Webpack.Common.FluxDispatcher.dispatch({
                                                type: "GUILD_SOUNDBOARD_SOUND_PLAY_LOCALLY",
                                                sound: { soundId: data.soundId, guildId: data.sourceGuildId || "0" },
                                                channelId,
                                                trigger: "SOUNDBOARD",
                                            });
                                        } catch (_) { }
                                        result = { ok: true };
                                    } catch (e) {
                                        result = { ok: false, error: String(e?.body?.message || e) };
                                    }
                                    break;
                                }
                                case "$play_sound": {
                                    // "Utilise les sons embed de Discord" (demande user) : rejoue le
                                    // VRAI son natif du client (WebAudioSound — la classe que Discord
                                    // utilise lui-même pour ses cues mute/deafen/connexion), plutôt que
                                    // d'embarquer nos propres fichiers. Lookup par le NOM DE PROP réel
                                    // (findByProps("WebAudioSound")) — pas par un alias mangled par le
                                    // bundler (change à chaque build Discord) ni un ID de module en dur.
                                    // Simplification acceptée : on ne résout pas le nom de fichier par
                                    // soundpack custom (Halloween/Hiver/…) — juste le nom d'évènement, qui
                                    // EST déjà le bon fichier pour tout le monde sauf pack thématique actif
                                    // (rare) → dégrade proprement sur le son classique plutôt que planter.
                                    try {
                                        const Snd = Vencord.Webpack.findByProps("WebAudioSound")?.WebAudioSound;
                                        if (Snd && data.name) new Snd(data.name, data.name, 1, "default").play();
                                    } catch (_) { }
                                    result = true;
                                    break;
                                }
                                case "$get_text_channels": {
                                    // Serveurs → salons texte (type 0) + annonces (type 5) accessibles.
                                    const GS = Vencord.Webpack.Common.GuildStore;
                                    const GCS = Vencord.Webpack.findStore("GuildChannelStore");
                                    const SGS = Vencord.Webpack.findStore("SortedGuildStore");
                                    const sortedIds = SGS?.getFlattenedGuildIds?.() ?? Object.keys(GS.getGuilds());
                                    const allGuilds = GS.getGuilds();
                                    result = [];
                                    for (const gid of sortedIds) {
                                        const guild = allGuilds[gid];
                                        if (!guild) continue;
                                        try {
                                            const gc = GCS.getChannels(guild.id);
                                            const list = gc?.SELECTABLE || [];
                                            const channels = list
                                                .map(e => {
                                                    const ch = e.channel ?? e;
                                                    if (!ch || (ch.type !== 0 && ch.type !== 5)) return null;
                                                    return { id: String(ch.id), name: String(ch.name), type: ch.type };
                                                })
                                                .filter(Boolean);
                                            if (channels.length)
                                                result.push({ id: String(guild.id), name: String(guild.name), icon: guild.icon || null, channels });
                                        } catch (_) { }
                                    }
                                    break;
                                }
                                case "$get_messages": {
                                    // MessageStore est vide pour un salon non ouvert → RestAPI (newest-first,
                                    // on inverse pour l'ordre de lecture). Timestamps ISO. `before` = pagination
                                    // vers l'historique (id du plus vieux message déjà chargé côté frontend).
                                    const mapMsg = window.__sc_mapMsg;
                                    // Discord compte les événements système (arrivée de membre, boost…)
                                    // parmi les "messages" du salon — sans filtre, les 30 derniers peuvent
                                    // n'être QUE ça sur un salon peu actif (vu en vrai #20 : plein d'écran
                                    // de "—" alors que du vrai contenu existe plus loin dans l'historique).
                                    // On les filtre ici et on remonte plusieurs pages si besoin pour garder
                                    // PAGE_SIZE (30) messages RÉELS — sinon `hasMore` côté frontend (basé
                                    // sur la taille du lot renvoyé) deviendrait faux dès qu'un lot brut est
                                    // filtré, cassant la pagination "load older".
                                    let before = data.before;
                                    const collected = [];
                                    for (let page = 0; page < 5 && collected.length < 30; page++) {
                                        const url = `/channels/${data.id}/messages?limit=30`
                                            + (before ? `&before=${encodeURIComponent(before)}` : "");
                                        const res = await Vencord.Webpack.Common.RestAPI.get({ url });
                                        const raw = res?.body || [];
                                        if (raw.length === 0) break;
                                        before = raw[raw.length - 1].id; // newest-first : le dernier du lot est le plus vieux
                                        for (const m of raw) {
                                            const mapped = mapMsg(m);
                                            if (mapped._hasBody) collected.push(mapped);
                                        }
                                        if (raw.length < 30) break; // fin réelle de l'historique
                                    }
                                    result = collected.slice(0, 30).reverse().map(({ _hasBody, ...rest }) => rest);
                                    break;
                                }
                                case "$send_message": {
                                    const body = { content: String(data.content || "") };
                                    if (data.reply_to) {
                                        body.message_reference = { message_id: String(data.reply_to) };
                                    }
                                    await Vencord.Webpack.Common.RestAPI.post({
                                        url: `/channels/${data.id}/messages`,
                                        body,
                                    });
                                    result = true;
                                    break;
                                }
                                case "$edit_message": {
                                    await Vencord.Webpack.Common.RestAPI.patch({
                                        url: `/channels/${data.id}/messages/${data.message_id}`,
                                        body: { content: String(data.content || "") },
                                    });
                                    result = true;
                                    break;
                                }
                                case "$delete_message": {
                                    await Vencord.Webpack.Common.RestAPI.del({
                                        url: `/channels/${data.id}/messages/${data.message_id}`,
                                    });
                                    result = true;
                                    break;
                                }
                                case "$add_reaction":
                                case "$remove_reaction": {
                                    // Emoji Unicode uniquement (cf. mapMsg) → encodeURIComponent direct,
                                    // pas besoin du format "name:id" réservé aux emojis custom.
                                    const method = data.type === "$add_reaction" ? "put" : "del";
                                    await Vencord.Webpack.Common.RestAPI[method]({
                                        url: `/channels/${data.id}/messages/${data.message_id}/reactions/${encodeURIComponent(data.emoji)}/@me`,
                                    });
                                    result = true;
                                    break;
                                }
                                case "$send_typing": {
                                    // Signale NOTRE frappe aux autres (symétrique du "X is
                                    // typing…" reçu) — best-effort, une frappe manquée n'est
                                    // pas grave, pas la peine de faire remonter une erreur.
                                    try {
                                        await Vencord.Webpack.Common.RestAPI.post({ url: `/channels/${data.id}/typing` });
                                    } catch (_) {}
                                    result = true;
                                    break;
                                }
                                case "$watch_channel": {
                                    // Salon actuellement ouvert dans le QAM/plein écran : seuls
                                    // les events MESSAGE_* de CE salon sont poussés en temps réel
                                    // (cf. intercepteur Flux) — sans ce filtre on relayerait tout
                                    // le trafic de toutes les guildes par le WS local pour rien.
                                    // id vide/absent = plus aucun salon suivi (fermeture).
                                    window.__sc_watched_channel = data.id ? String(data.id) : null;
                                    result = true;
                                    break;
                                }
                                case "$webrtc":
                                    return;
                                case "$WATCH_VIDEO":
                                    window.STEAMCORD_startVideoRelay(data.userId);
                                    return;
                                case "$UNWATCH_VIDEO":
                                    window.STEAMCORD_stopVideoRelay(data.userId);
                                    return;
                                case "$VIDEO_ANSWER": {
                                    const entry = window.STEAMCORD_VIDEO[data.userId];
                                    if (entry && entry.pc) await entry.pc.setRemoteDescription(new RTCSessionDescription(data.payload));
                                    return;
                                }
                                case "$POV_START":
                                    window.STEAMCORD_startPov(data.userId);
                                    return;
                                case "$POV_STOP":
                                    window.STEAMCORD_stopPov(data.userId);
                                    return;
                                case "$login_token": {
                                    const t = data.token;
                                    if (!t) return;
                                    const lm = Vencord.Webpack.find(m => m && typeof m.loginToken === "function");
                                    if (lm) lm.loginToken(t, true);
                                    else { localStorage.setItem("token", JSON.stringify(t)); location.reload(); }
                                    return;
                                }
                                case "$logout": {
                                    // Déconnexion TOTALE Discord : invalide le token côté serveur +
                                    // purge la session locale → retour page login (QR). Fallback :
                                    // purge localStorage + reload si l'action n'est pas trouvée.
                                    try {
                                        const auth = Vencord.Webpack.findByProps("logout", "loginToken");
                                        if (auth && typeof auth.logout === "function") auth.logout();
                                        else { localStorage.removeItem("token"); location.reload(); }
                                    } catch (e) {
                                        try { localStorage.removeItem("token"); location.reload(); } catch (_) {}
                                    }
                                    return;
                                }
                                case "$get_audio_processing": {
                                    // Réglages micro Discord (Voix & Vidéo). La réduction de bruit
                                    // est un tri-état : Krisp (noiseCancellation) > Standard
                                    // (noiseSuppression) > Aucune. + écho + gain auto.
                                    const MES = Vencord.Webpack.findStore("MediaEngineStore");
                                    const nc = !!MES.getNoiseCancellation();
                                    const ns = !!MES.getNoiseSuppression();
                                    result = {
                                        noise: nc ? "krisp" : (ns ? "standard" : "none"),
                                        echoCancellation: !!MES.getEchoCancellation(),
                                        automaticGainControl: !!MES.getAutomaticGainControl(),
                                        ncSupported: MES.isNoiseCancellationSupported ? !!MES.isNoiseCancellationSupported() : true,
                                        nsSupported: MES.isNoiseSuppressionSupported ? !!MES.isNoiseSuppressionSupported() : true,
                                        agcSupported: MES.isAutomaticGainControlSupported ? !!MES.isAutomaticGainControlSupported() : true,
                                    };
                                    break;
                                }
                                case "$set_stream_quality": {
                                    // Issue #33 — qualité du partage d'écran.
                                    // On écrit la screenshareQuality de Vesktop,
                                    // que le patch screenShareFixes de Vencord
                                    // applique comme contrainte sur la piste
                                    // vidéo À L'ACQUISITION : c'est l'encodeur de
                                    // Discord qui obéit, pas un transcodage de
                                    // notre côté. Un partage DÉJÀ en cours garde
                                    // donc son réglage jusqu'au suivant.
                                    // localStorage est supprimé par Discord sur
                                    // discord.com — on passe par celui d'une
                                    // iframe de même origine, comme Vencord.
                                    const _fq = document.createElement("iframe");
                                    document.body.append(_fq);
                                    try {
                                        const _lsq = _fq.contentWindow.localStorage;
                                        const stq = JSON.parse(_lsq.getItem("VesktopState") || "{}");
                                        const q = {};
                                        if (data.resolution && data.resolution !== "source") q.resolution = data.resolution;
                                        if (data.frameRate && data.frameRate !== "source") q.frameRate = data.frameRate;
                                        if (Object.keys(q).length) stq.screenshareQuality = Object.assign(stq.screenshareQuality || {}, q);
                                        else delete stq.screenshareQuality;
                                        _lsq.setItem("VesktopState", JSON.stringify(stq));
                                        result = { quality: stq.screenshareQuality || null };
                                    } finally {
                                        _fq.remove();
                                    }
                                    break;
                                }
                                case "$set_noise_reduction": {
                                    // data.mode: "none" | "standard" | "krisp"
                                    // Le module d'actions peut manquer selon le bundle (issue #14 :
                                    // no-op silencieux = réglage « qui ne prend pas ») → fallback
                                    // FluxDispatcher, et une ERREUR remonte si rien n'a pris.
                                    const SET = Vencord.Webpack.findByProps("setNoiseCancellation");
                                    if (SET) {
                                        if (data.mode === "krisp") { SET.setNoiseSuppression(false); SET.setNoiseCancellation(true); }
                                        else if (data.mode === "standard") { SET.setNoiseCancellation(false); SET.setNoiseSuppression(true); }
                                        else { SET.setNoiseCancellation(false); SET.setNoiseSuppression(false); }
                                    } else {
                                        const FD = Vencord.Webpack.Common.FluxDispatcher;
                                        FD.dispatch({ type: "AUDIO_SET_NOISE_CANCELLATION", enabled: data.mode === "krisp" });
                                        FD.dispatch({ type: "AUDIO_SET_NOISE_SUPPRESSION", enabled: data.mode === "standard" });
                                    }
                                    await new Promise(r => setTimeout(r, 150));
                                    const MES = Vencord.Webpack.findStore("MediaEngineStore");
                                    const applied = MES.getNoiseCancellation() ? "krisp" : (MES.getNoiseSuppression() ? "standard" : "none");
                                    result = applied === data.mode ? { noise: applied }
                                        : { noise: applied, error: "noise setting did not apply (module not found?)" };
                                    break;
                                }
                                case "$set_echo_cancellation": {
                                    const SET = Vencord.Webpack.findByProps("setEchoCancellation");
                                    if (SET) SET.setEchoCancellation(!!data.enabled);
                                    else Vencord.Webpack.Common.FluxDispatcher.dispatch({ type: "AUDIO_SET_ECHO_CANCELLATION", enabled: !!data.enabled });
                                    await new Promise(r => setTimeout(r, 150));
                                    const MES = Vencord.Webpack.findStore("MediaEngineStore");
                                    const ec = !!MES.getEchoCancellation();
                                    result = ec === !!data.enabled ? { echoCancellation: ec }
                                        : { echoCancellation: ec, error: "echo setting did not apply (module not found?)" };
                                    break;
                                }
                                case "$set_automatic_gain_control": {
                                    const SET = Vencord.Webpack.findByProps("setAutomaticGainControl");
                                    if (SET) SET.setAutomaticGainControl(!!data.enabled);
                                    else Vencord.Webpack.Common.FluxDispatcher.dispatch({ type: "AUDIO_SET_AUTOMATIC_GAIN_CONTROL", enabled: !!data.enabled });
                                    await new Promise(r => setTimeout(r, 150));
                                    const MES = Vencord.Webpack.findStore("MediaEngineStore");
                                    const agc = !!MES.getAutomaticGainControl();
                                    result = agc === !!data.enabled ? { automaticGainControl: agc }
                                        : { automaticGainControl: agc, error: "AGC setting did not apply (module not found?)" };
                                    break;
                                }
                            }
                        } catch (error) {
                            // `JSON.stringify(new Error("x"))` vaut "{}" : renvoyer l'objet
                            // Error tel quel effaçait le motif de l'échec sur le fil, et le
                            // backend recevait une réponse d'apparence valide — donc un
                            // SUCCÈS côté frontend, qui appliquait sa mise à jour optimiste
                            // avant que le prochain rafraîchissement la reprenne. Vu de
                            // l'utilisateur : "j'ai édité et rien ne s'est passé", sans une
                            // ligne de log nulle part (David #21).
                            //
                            // Clé DÉDIÉE `__sc_error` et pas `error` : plusieurs commandes
                            // renvoient légitimement un champ `error` en avertissement DOUX
                            // à côté d'un résultat exploitable (`$set_noise_cancellation` et
                            // consorts : "le réglage n'a pas pris"). Les confondre ferait
                            // échouer ces commandes-là alors qu'elles ont répondu.
                            result = { __sc_error: window.__sc_describeError(error) };
                            console.error("[Steamcord] " + data.type + " failed:", error);
                            if (data.increment == undefined) return;
                        }
                        const payload = {
                            type: "$steamcord_request",
                            increment: data.increment,
                            // `?? {}` et PAS `|| {}` : `|| {}` transformait un résultat
                            // booléen `false` (ex. get_local_mute d'un user NON muté) en
                            // `{}` → côté frontend `!!{}` = true → participant affiché
                            // « muet » à tort. `?? {}` ne remplace que null/undefined et
                            // préserve false/0/"".
                            result: result ?? {}
                        };
                        console.debug(data, payload);
                        window.STEAMCORD_WS.send(JSON.stringify(payload));
                        return;
                    }
                    FluxDispatcher.dispatch(data);
                });

                window.STEAMCORD_WS.onopen = function (e) {
                    // CEF only: kick off the mic relay handshake. In Vesktop the mic is
                    // native — don't touch getUserMedia.
                    if (!window.STEAMCORD_IS_VESKTOP) navigator.mediaDevices.getUserMedia();
                    Vencord.Webpack.waitFor("useState", t => {
                        window.STEAMCORD_WS.send(JSON.stringify({ type: "LOADED", result: true }));
                        Vencord.Webpack.onceReady.then(() => {
                            const user = Vencord.Webpack.Common.UserStore.getCurrentUser();
                            if (user) {
                                window.STEAMCORD_WS.send(JSON.stringify({ type: "CONNECTION_OPEN", user }));
                            } else if (window.STEAMCORD_LAST_QR) {
                                window.STEAMCORD_WS.send(JSON.stringify({ type: "REMOTE_AUTH_QR_SVG", svg_b64: window.STEAMCORD_LAST_QR }));
                            }
                        });
                    });
                }

                window.STEAMCORD_WS.onclose = function (e) {
                    FluxDispatcher._interceptors.pop()
                    setTimeout(function () {
                        connect();
                    }, 100);
                };

                window.STEAMCORD_WS.onerror = function (err) {
                    console.error('Socket encountered error: ', err.message, 'Closing socket');
                    window.STEAMCORD_WS.close();
                };

                Vencord.Webpack.onceReady.then(t => {
                    const user = Vencord.Webpack.Common.UserStore.getCurrentUser();
                    if (user) {
                        window.STEAMCORD_WS.send(JSON.stringify({ type: "CONNECTION_OPEN", user }));
                    }
                });

                FluxDispatcher.addInterceptor(e => {
                    if (e.type == "CHANNEL_SELECT") patchTypingField();

                    // Incoming DM call → Steam toast (DMs only; guild calls are useless).
                    // Respect the user's Discord status: skip if invisible or DnD (busy).
                    try {
                        if (e.type && e.type.indexOf("CALL") === 0)
                            console.log("[Steamcord] CALL event: " + e.type + " ringing=" + JSON.stringify(e.ringing) + " ch=" + e.channelId);
                        if (e.type === "CALL_DELETE" && window.__sc_ringing) {
                            delete window.__sc_ringing[e.channelId];
                        } else if ((e.type === "CALL_CREATE" || e.type === "CALL_UPDATE") && Array.isArray(e.ringing)) {
                            const me = Vencord.Webpack.Common.UserStore.getCurrentUser();
                            window.__sc_ringing = window.__sc_ringing || {};
                            if (!e.ringing.includes(me?.id)) {
                                delete window.__sc_ringing[e.channelId]; // ring stopped / answered
                            } else {
                                const ch = Vencord.Webpack.Common.ChannelStore.getChannel(e.channelId);
                                console.log("[Steamcord] incoming ring for me, ch.type=" + ch?.type + " status=" + Vencord.Webpack.findStore("PresenceStore")?.getStatus?.(me.id));
                                const isDM = ch && (ch.type === 1 || ch.type === 3);
                                const PresenceStore = Vencord.Webpack.findStore("PresenceStore");
                                const status = PresenceStore?.getStatus?.(me.id);
                                const muted = status === "invisible" || status === "dnd";
                                if (isDM && !muted && !window.__sc_ringing[e.channelId]) {
                                    window.__sc_ringing[e.channelId] = true;
                                    let caller = ch.name;
                                    let caller_avatar = null; // avatar Discord de l'appelant → persona de la notif Steam
                                    const r = (ch.rawRecipients && ch.rawRecipients[0]) ||
                                              (ch.recipients && ch.recipients[0]);
                                    const u = (r && typeof r === "object") ? r
                                            : Vencord.Webpack.Common.UserStore.getUser(r);
                                    if (!caller) caller = u?.global_name || u?.username || "Discord";
                                    if (u?.id && u?.avatar)
                                        caller_avatar = "https://cdn.discordapp.com/avatars/" + u.id + "/" + u.avatar + ".png?size=64";
                                    window.STEAMCORD_WS.send(JSON.stringify({ type: "CALL_RING", caller, caller_avatar, channel_id: String(e.channelId) }));
                                }
                            }
                        } else if (e.type === "TYPING_START" && e.userId) {
                            // "X is typing…" pour la vue plein écran (#20) — pas nous-même,
                            // et Discord ne dit jamais "a arrêté d'écrire" (le frontend
                            // efface tout seul après quelques secondes sans nouvel event).
                            const me = Vencord.Webpack.Common.UserStore.getCurrentUser();
                            if (e.userId !== me?.id) {
                                const u = Vencord.Webpack.Common.UserStore.getUser(e.userId);
                                window.STEAMCORD_WS.send(JSON.stringify({
                                    type: "TYPING_START",
                                    channel_id: String(e.channelId),
                                    username: u?.global_name || u?.username || "…",
                                }));
                            }
                        } else if ((e.type === "MESSAGE_CREATE" || e.type === "MESSAGE_UPDATE")
                                   && window.__sc_watched_channel && e.message
                                   && String(e.message.channel_id || e.channelId) === window.__sc_watched_channel) {
                            // Push temps réel du salon suivi (retour user : les messages
                            // doivent arriver à la seconde, pas au prochain poll). Même
                            // mapping que $get_messages pour un rendu identique.
                            // MESSAGE_UPDATE couvre aussi les embeds résolus après coup
                            // (un lien posté devient une vignette quelques instants plus
                            // tard via un UPDATE). Les events système sans corps (arrivée
                            // de membre…) sont filtrés comme au chargement.
                            const mapped = window.__sc_mapMsg(e.message);
                            if (mapped._hasBody) {
                                delete mapped._hasBody;
                                window.STEAMCORD_WS.send(JSON.stringify({
                                    type: "CHAT_MESSAGE",
                                    op: e.type === "MESSAGE_CREATE" ? "create" : "update",
                                    channel_id: window.__sc_watched_channel,
                                    message: mapped,
                                }));
                            }
                        } else if (e.type === "MESSAGE_DELETE" && window.__sc_watched_channel && e.id
                                   && String(e.channelId) === window.__sc_watched_channel) {
                            window.STEAMCORD_WS.send(JSON.stringify({
                                type: "CHAT_MESSAGE",
                                op: "delete",
                                channel_id: window.__sc_watched_channel,
                                message_id: String(e.id),
                            }));
                        } else if ((e.type === "MESSAGE_REACTION_ADD" || e.type === "MESSAGE_REACTION_REMOVE")
                                   && window.__sc_watched_channel && e.messageId
                                   && String(e.channelId) === window.__sc_watched_channel
                                   && e.emoji && !e.emoji.id) { // Unicode uniquement, cf. mapMsg
                            const me = Vencord.Webpack.Common.UserStore.getCurrentUser();
                            window.STEAMCORD_WS.send(JSON.stringify({
                                type: "CHAT_MESSAGE",
                                op: e.type === "MESSAGE_REACTION_ADD" ? "reaction_add" : "reaction_remove",
                                channel_id: window.__sc_watched_channel,
                                message_id: String(e.messageId),
                                emoji: e.emoji.name || "",
                                me: String(e.userId) === String(me?.id),
                            }));
                        }
                    } catch (_) {}

                    const shouldPass = [
                        "CONNECTION_OPEN",
                        "LOGOUT",
                        "CONNECTION_CLOSED",
                        "VOICE_STATE_UPDATES",
                        "VOICE_STATE_UPDATE",
                        "VOICE_CHANNEL_SELECT",
                        "AUDIO_TOGGLE_SELF_MUTE",
                        "AUDIO_TOGGLE_SELF_DEAF",
                        "RPC_NOTIFICATION_CREATE",
                        "STREAM_START",
                        "STREAM_STOP",
                        "SPEAKING"
                    ].includes(e.type);
                    if (shouldPass) {
                        // Notification de message : enrichit l'event avec le contexte
                        // (MP ou #chan de serveur) — le backend ne peut pas interroger
                        // les stores Discord. Les mutes/réglages de notif Discord sont
                        // déjà respectés : NOTIFICATION_CREATE n'arrive que si Discord
                        // aurait notifié.
                        if (e.type === "RPC_NOTIFICATION_CREATE") {
                            try {
                                const ch = Vencord.Webpack.Common.ChannelStore.getChannel(e.channelId);
                                e.__sc_dm = !!ch && (ch.type === 1 || ch.type === 3);
                                if (ch && !e.__sc_dm) {
                                    e.__sc_channel = ch.name || "";
                                    const g = ch.guild_id && Vencord.Webpack.Common.GuildStore?.getGuild?.(ch.guild_id);
                                    e.__sc_guild = (g && g.name) || "";
                                }
                            } catch (_) {}
                        }
                        console.log("Dispatching Steamcord event: ", e);
                        window.STEAMCORD_WS.send(JSON.stringify(e));
                    }
                });
                console.log("Steamcord: Added event interceptor");

                // Robust voice-channel tracking: Discord does NOT reliably emit
                // VOICE_CHANNEL_SELECT when you're force-disconnected by joining voice on
                // another device. Poll the store and notify the backend on any change so
                // the QAM state always matches reality (join / leave / move / kicked).
                let steamcordLastVCId = undefined;
                setInterval(() => {
                    try {
                        if (!window.STEAMCORD_WS || window.STEAMCORD_WS.readyState !== 1) return;
                        const selStore = Vencord.Webpack.findStore("SelectedChannelStore");
                        const vcid = selStore?.getVoiceChannelId?.() ?? null;
                        if (vcid !== steamcordLastVCId) {
                            steamcordLastVCId = vcid;
                            let guildId = null;
                            if (vcid) {
                                const ch = Vencord.Webpack.Common.ChannelStore.getChannel(vcid);
                                guildId = ch?.guild_id ?? null;
                            }
                            console.log("[Steamcord] voice channel changed → " + vcid);
                            window.STEAMCORD_WS.send(JSON.stringify({ type: "VOICE_CHANNEL_SELECT", channelId: vcid, guildId }));
                        }

                        // RÉCONCILIATION mute/deaf depuis le STORE autoritatif (et pas
                        // seulement les deltas VOICE_STATE_UPDATES). Discord peut émettre
                        // un état muet TRANSITOIRE à la connexion d'un participant ; si le
                        // delta de nettoyage est manqué (ou arrive sur un autre channelId),
                        // l'icône « muet » restait collée alors que la personne est audible.
                        // On relit la vérité (getVoiceStatesForChannel = ce que l'UI Discord
                        // affiche) et on ne ré-émet QUE si le signal mute/deaf a changé →
                        // auto-guérison sous 2 s, zéro spam / re-render inutile.
                        if (vcid) {
                            const VSS = Vencord.Webpack.findStore("VoiceStateStore");
                            const states = VSS?.getVoiceStatesForChannel?.(vcid) || {};
                            const vsArr = [];
                            for (const uid in states) {
                                const v = states[uid] || {};
                                vsArr.push({
                                    userId: uid, channelId: vcid,
                                    mute: !!(v.mute || v.selfMute), selfMute: !!v.selfMute,
                                    deaf: !!(v.deaf || v.selfDeaf), selfDeaf: !!v.selfDeaf,
                                    video: !!v.selfVideo, selfVideo: !!v.selfVideo,
                                    suppress: !!v.suppress
                                });
                            }
                            const sig = JSON.stringify(vsArr.map(s => [s.userId, s.mute, s.deaf, s.video]));
                            if (sig !== window.__sc_lastVoiceSig) {
                                window.__sc_lastVoiceSig = sig;
                                window.STEAMCORD_WS.send(JSON.stringify({ type: "VOICE_STATE_UPDATES", voiceStates: vsArr }));
                            }
                        } else {
                            window.__sc_lastVoiceSig = undefined;
                        }
                    } catch (_) {}
                }, 2000);

                // Sync des Go Live actifs → is_live des participants dans le QAM. Discord
                // n'émet STREAM_START qu'au DÉMARRAGE : un stream lancé avant notre
                // connexion serait manqué. On diffe l'ensemble des streams actifs et on
                // émet STREAM_START/STOP synthétiques sur changement (clé = call/guild:…:ownerId).
                let steamcordStreamKeys = new Set();
                const steamcordStreamMisses = new Map(); // key -> polls consécutifs où le stream manque
                setInterval(() => {
                    try {
                        if (!window.STEAMCORD_WS || window.STEAMCORD_WS.readyState !== 1) return;
                        const SCS = Vencord.Webpack.findStore("SelectedChannelStore");
                        const vcid = SCS?.getVoiceChannelId?.() ?? null;
                        const now = new Set();
                        if (vcid) {
                            for (const { key, s } of window.__sc_streamsForChannel(vcid)) {
                                now.add(key);
                                steamcordStreamMisses.delete(key);
                                if (!steamcordStreamKeys.has(key)) {
                                    window.STEAMCORD_WS.send(JSON.stringify({ type: "STREAM_START", streamKey: key }));
                                    // Stream (re)créé : si on relaie déjà son propriétaire
                                    // (l'ami a fermé puis rouvert son partage, Discord nous
                                    // re-abonne tout seul), la piste rattrapée par le
                                    // keepalive est souvent NOIRE (pas encore de keyframe) et
                                    // n'est jamais 'ended' → elle reste noire (issue #8). On
                                    // relance proprement le relais : re-watch + capture fraîche.
                                    const owner = s && (s.ownerId || s.userId);
                                    if (owner && window.STEAMCORD_VIDEO[owner])
                                        setTimeout(() => { try { window.STEAMCORD_startVideoRelay(owner); } catch (_) {} }, 1500);
                                }
                            }
                        }
                        // STOP débouncé : le store rend parfois TRANSITOIREMENT vide
                        // (renégociation de qualité, hoquet de reconnexion) → le bouton
                        // « Voir » disparaissait alors que l'ami streamait toujours
                        // (issue #5). Un stream doit manquer 3 polls consécutifs (~6 s)
                        // avant qu'on émette STREAM_STOP.
                        for (const key of steamcordStreamKeys) {
                            if (now.has(key)) continue;
                            const miss = (steamcordStreamMisses.get(key) || 0) + 1;
                            if (miss >= 3) {
                                steamcordStreamMisses.delete(key);
                                window.STEAMCORD_WS.send(JSON.stringify({ type: "STREAM_STOP", streamKey: key }));
                            } else {
                                steamcordStreamMisses.set(key, miss);
                                now.add(key); // considéré actif tant que le débounce court
                            }
                        }
                        steamcordStreamKeys = now;
                    } catch (_) {}
                }, 2000);

                // Chromium freezes the occluded BrowserView: the voice WebRTC stalls at
                // DTLS_CONNECTING AND Discord's mic capture never runs → nobody hears
                // anyone. Keep the view rendered (1×1, barely visible) for the WHOLE time
                // we're in a voice channel so both the connection and the mic capture stay
                // alive; hide it again when we leave the call.
                let steamcordVoiceShown = false;
                setInterval(() => {
                    try {
                        const inVoice = !!Vencord.Webpack.findStore("SelectedChannelStore").getVoiceChannelId();
                        if (inVoice && !steamcordVoiceShown) {
                            steamcordVoiceShown = true;
                            fetch("http://127.0.0.1:65123/voice_render", { mode: "no-cors" }).catch(() => {});
                        } else if (!inVoice && steamcordVoiceShown) {
                            steamcordVoiceShown = false;
                            fetch("http://127.0.0.1:65123/voice_hide", { mode: "no-cors" }).catch(() => {});
                        }
                    } catch (_) {}
                }, 1000);
            }
            connect();
        });

        (() => {
            // Même remplacement que patchTypingField : un écouteur délégué au
            // lieu d'un sondage. Le clearInterval était bien atteint ici, mais
            // les <input> apparus après le premier tick n'étaient jamais câblés.
            document.addEventListener("click", (e) => {
                try {
                    if (window.location.pathname !== "/login") return;
                    const t = e.target;
                    if (t && t.tagName === "INPUT")
                        fetch("http://127.0.0.1:65123/openkb", { mode: "no-cors" });
                } catch (err) { }
            }, true);
        })();

        // ── Wake-lock audio (issue #3) ──────────────────────────────────────
        // Le mixeur Steam du Deck montre un flux de LECTURE « Chromium » qui
        // SURVIT à l'appel : des sinks WebRTC (<audio>/<video> à srcObject)
        // restent « playing » et des pistes micro restent live après avoir
        // quitté le vocal → Chromium garde sa sortie audio ouverte → l'écran ne
        // s'éteint jamais. Suspendre le SEUL audioContext du MediaEngine
        // (v1.14.1) ne suffisait pas : sur la BC-250 il n'existe même pas en
        // appel — les vrais porteurs du wake-lock sont les sinks/pistes. On
        // traque donc tout ce que la page crée pour pouvoir le libérer.
        window.__STEAMCORD_ACS = window.__STEAMCORD_ACS || [];
        window.__STEAMCORD_GUM_STREAMS = window.__STEAMCORD_GUM_STREAMS || [];
        (function installAudioTrackers() {
            if (window.__STEAMCORD_AUDIO_TRACKERS) return;
            window.__STEAMCORD_AUDIO_TRACKERS = true;
            for (const name of ["AudioContext", "webkitAudioContext"]) {
                const Orig = window[name];
                if (!Orig) continue;
                const Wrapped = function (...args) {
                    const inst = new Orig(...args);
                    window.__STEAMCORD_ACS.push(inst);
                    return inst;
                };
                Wrapped.prototype = Orig.prototype;
                window[name] = Wrapped;
            }
            // Wrapper PASSE-PLAT (≠ override micro CEF plus haut : on ne remplace
            // pas la capture, on mémorise juste les streams rendus pour pouvoir
            // stopper les pistes orphelines hors appel). Vesktop only : sous CEF
            // installMicOverride ré-écrase getUserMedia toutes les 2 s.
            if (window.STEAMCORD_IS_VESKTOP) {
                try {
                    const md = navigator.mediaDevices;
                    const origGUM = md.getUserMedia.bind(md);
                    Object.defineProperty(md, "getUserMedia", {
                        configurable: true,
                        value: function (constraints) {
                            const p = origGUM(constraints);
                            p.then((s) => { window.__STEAMCORD_GUM_STREAMS.push(s); }).catch(() => {});
                            return p;
                        },
                    });
                } catch (_) {}
            }
        })();

        // Hors appel (SelectedChannelStore.getVoiceChannelId, même source de
        // vérité que le poller vocal) : suspendre en continu les AudioContexts,
        // et UNE passe de nettoyage profond ~5 s après la fin d'appel
        // (edge-triggered : un test micro lancé plus tard dans les réglages
        // n'est pas impacté). Rejoindre un appel re-resume en ~1,5 s ; Discord
        // recrée sinks et pistes à chaque connexion vocale.
        (function keepAudioAlive() {
            let wasInCall = false;
            let cleanupAt = 0;
            setInterval(() => {
                try {
                    const me = Vencord.Webpack.findStore?.("MediaEngineStore")?.getMediaEngine?.();
                    const engineCtx = me?.audioContext;
                    const inCall = !!Vencord.Webpack.findStore?.("SelectedChannelStore")?.getVoiceChannelId?.();
                    if (inCall) {
                        wasInCall = true;
                        cleanupAt = 0;
                        if (engineCtx && engineCtx.state === "suspended") {
                            engineCtx.resume();
                            console.log("[Steamcord] Resumed MediaEngine AudioContext (in call)");
                        }
                        return;
                    }
                    window.__STEAMCORD_ACS = window.__STEAMCORD_ACS.filter((c) => c.state !== "closed");
                    const ctxs = engineCtx ? [engineCtx, ...window.__STEAMCORD_ACS] : [...window.__STEAMCORD_ACS];
                    for (const ctx of ctxs) {
                        if (ctx.state === "running") {
                            try { ctx.suspend(); console.log("[Steamcord] Suspended AudioContext (idle, frees the audio wake-lock)"); } catch (_) {}
                        }
                    }
                    if (wasInCall) { wasInCall = false; cleanupAt = Date.now() + 5000; }
                    if (cleanupAt && Date.now() >= cleanupAt) {
                        cleanupAt = 0;
                        let sinks = 0, mics = 0;
                        for (const el of document.querySelectorAll("audio, video")) {
                            // Seulement les sinks WebRTC (srcObject) — jamais un média
                            // « normal » (sons de notification, aperçus…).
                            if (el.srcObject && !el.paused) {
                                try { el.pause(); el.srcObject = null; sinks++; } catch (_) {}
                            }
                        }
                        for (const stream of window.__STEAMCORD_GUM_STREAMS.splice(0)) {
                            for (const t of stream.getTracks()) {
                                if (t.readyState === "live") { try { t.stop(); mics++; } catch (_) {} }
                            }
                        }
                        if (sinks || mics)
                            console.log("[Steamcord] post-call audio cleanup: " + sinks + " sink(s), " + mics + " capture track(s) released");
                    }
                } catch(_) {}
            }, 1500);
        })();

        // Token login: callable from QAM via CDP
        window.steamcordLoginWithToken = function(token) {
            const loginMod = Vencord.Webpack.find(m => m && typeof m.loginToken === "function");
            if (loginMod) {
                loginMod.loginToken(token, true);
                return "ok";
            }
            localStorage.setItem("token", JSON.stringify(token));
            location.reload();
            return "reload";
        };

        // Canvas QR mirror: extract Discord's own QR when the tab is visible (no spinner)
        window.STEAMCORD_LAST_QR = null;
        (function startCanvasQRMirror() {
            const sendQR = (url) => {
                window.STEAMCORD_LAST_QR = url;
                if (window.STEAMCORD_WS?.readyState === 1)
                    window.STEAMCORD_WS.send(JSON.stringify({ type: "REMOTE_AUTH_QR_SVG", svg_b64: url }));
            };
            // Discord rend désormais le QR en <svg> (≈160px, viewBox carré "0 0 37 37",
            // un gros <path> de modules), PAS en canvas (le canvas 240×240 est un
            // placeholder caché/coloré). On capture le SVG → data URL que l'<img> du QAM
            // affiche directement. Détection = SVG carré 100–300px avec une grosse data
            // de path (le QR ≈ 35 Ko ; les logos/icônes ont des paths courts).
            const findQRSvg = () => {
                for (const s of document.querySelectorAll("svg")) {
                    const r = s.getBoundingClientRect();
                    if (r.width < 100 || r.width > 320 || Math.abs(r.width - r.height) > 30) continue;
                    let pathLen = 0;
                    for (const p of s.querySelectorAll("path, rect")) pathLen += (p.getAttribute("d") || "").length;
                    if (pathLen > 3000) return s;
                }
                return null;
            };
            const svgToDataUrl = (svg) => {
                const clone = svg.cloneNode(true);
                clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
                const s = new XMLSerializer().serializeToString(clone);
                return "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(s)));
            };
            const sendScanned = (b) => {
                if (window.STEAMCORD_WS?.readyState === 1)
                    window.STEAMCORD_WS.send(JSON.stringify({ type: "REMOTE_AUTH_SCANNED", scanned: b }));
            };
            // CAPTCHA au niveau PAGE (#37). Le QR affiché sous Vesktop est celui de
            // Discord lui-même : quand Discord défie l'IP, il plante un hCaptcha SUR
            // la page de login et n'émet alors JAMAIS de ticket de remote-auth — le
            // QR se régénère toutes les ~30 s, indéfiniment, sans le moindre indice
            // pour l'utilisateur. L'AUTRE détection de CAPTCHA (exchange_ticket qui
            // reçoit un 400 avec captcha_key) ne couvre QUE le remote-auth maison,
            // lequel est désactivé sous Vesktop — elle ne pouvait donc structurellement
            // pas se déclencher ici. On regarde la page.
            // Deux garde-fous, parce que hCaptcha sème des iframes qui ne sont
            // PAS un défi visible :
            //  • la TAILLE — l'iframe d'API fait 0×0. Mais le plancher doit rester
            //    BAS : la case « je ne suis pas un robot » ne fait que ~302×76,
            //    un seuil à 80 de haut la ratait, c'est-à-dire le cas le plus
            //    courant chez Discord ;
            //  • la VISIBILITÉ — l'iframe du défi en grille existe déjà, à sa
            //    taille définitive, mais en visibility:hidden tant qu'on n'a pas
            //    coché la case. Sans ce test on annoncerait un défi trop tôt.
            const CAPTCHA_SRC = /hcaptcha\.com|recaptcha|arkoselabs\.com|funcaptcha/i;
            const captchaRect = (f) => {
                if (!CAPTCHA_SRC.test(f.src || "")) return null;
                const r = f.getBoundingClientRect();
                if (r.width < 80 || r.height < 40) return null;
                const cs = getComputedStyle(f);
                if (cs.visibility === "hidden" || cs.display === "none") return null;
                if (parseFloat(cs.opacity || "1") < 0.1) return null;
                return r;
            };
            const findCaptcha = () => {
                for (const f of document.querySelectorAll("iframe"))
                    if (captchaRect(f)) return true;
                return false;
            };
            const sendCaptcha = (b) => {
                if (window.STEAMCORD_WS?.readyState === 1)
                    window.STEAMCORD_WS.send(JSON.stringify({ type: "REMOTE_AUTH_CAPTCHA", captcha: b }));
            };
            let lastUrl = null, lastScanned = false, lastCaptcha = false;
            setInterval(() => {
                try {
                    if (Vencord.Webpack.Common.UserStore?.getCurrentUser?.()) {
                        if (lastUrl !== null) { lastUrl = null; sendQR(null); }
                        if (lastScanned) { lastScanned = false; sendScanned(false); }
                        if (lastCaptcha) { lastCaptcha = false; sendCaptcha(false); }
                        return;
                    }
                    // AVANT la branche QR : Discord affiche le défi EN MÊME TEMPS que
                    // le QR code, donc le `return` du bloc QR ferait rater le cas.
                    const captcha = findCaptcha();
                    if (captcha !== lastCaptcha) { lastCaptcha = captcha; sendCaptcha(captcha); }
                    const svg = findQRSvg();
                    if (svg) {
                        if (lastScanned) { lastScanned = false; sendScanned(false); }
                        const url = svgToDataUrl(svg);
                        if (url.length > 2000 && url !== lastUrl) { lastUrl = url; sendQR(url); }
                        return;
                    }
                    // Pas de QR. Soit SCANNÉ (Discord affiche « regarde ton téléphone » avec
                    // l'avatar du compte → attente de validation), soit en chargement.
                    if (lastUrl !== null) { lastUrl = null; sendQR(null); }
                    const scanned = !!document.querySelector('img[src*="avatars"]');
                    if (scanned !== lastScanned) { lastScanned = scanned; sendScanned(scanned); }
                } catch (e) { /* ignore */ }
            }, 1500);
        })();

        // Remote auth: our own WS, QR from segno (Python), ticket sent to backend for POST with desktop UA
        window.STEAMCORD_REMOTE_AUTH_ACTIVE = false;
        window.steamcordStartRemoteAuth = async function() {
            if (window.STEAMCORD_REMOTE_AUTH_ACTIVE) return;
            window.STEAMCORD_REMOTE_AUTH_ACTIVE = true;
            try {
                const keyPair = await crypto.subtle.generateKey(
                    { name: "RSA-OAEP", modulusLength: 2048,
                      publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" },
                    true, ["decrypt"]
                );
                const pubDer = await crypto.subtle.exportKey("spki", keyPair.publicKey);
                const encodedPub = btoa(String.fromCharCode(...new Uint8Array(pubDer)));
                const privJwk = await crypto.subtle.exportKey("jwk", keyPair.privateKey);

                const ws = new WebSocket("wss://remote-auth-gateway.discord.gg/?v=2");
                let hbTimer = null;

                ws.onmessage = async (event) => {
                    const data = JSON.parse(event.data);
                    const op = data.op;
                    if (op === "hello") {
                        hbTimer = setInterval(() => ws.send(JSON.stringify({ op: "heartbeat" })), data.heartbeat_interval);
                        ws.send(JSON.stringify({ op: "init", encoded_public_key: encodedPub }));
                    } else if (op === "nonce_proof") {
                        const enc = Uint8Array.from(atob(data.encrypted_nonce), c => c.charCodeAt(0));
                        const nonce = await crypto.subtle.decrypt({ name: "RSA-OAEP" }, keyPair.privateKey, enc);
                        const hash = await crypto.subtle.digest("SHA-256", nonce);
                        const proof = btoa(String.fromCharCode(...new Uint8Array(hash)))
                            .replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
                        ws.send(JSON.stringify({ op: "nonce_proof", proof }));
                    } else if (op === "pending_remote_init") {
                        if (window.STEAMCORD_WS?.readyState === 1)
                            window.STEAMCORD_WS.send(JSON.stringify({ type: "REMOTE_AUTH_FINGERPRINT", fingerprint: data.fingerprint }));
                    } else if (op === "pending_login") {
                        if (hbTimer) clearInterval(hbTimer);
                        ws.close(1000);
                        window.STEAMCORD_REMOTE_AUTH_ACTIVE = false;
                        // Send ticket + private key to backend — Python makes the POST with desktop UA
                        if (window.STEAMCORD_WS?.readyState === 1)
                            window.STEAMCORD_WS.send(JSON.stringify({
                                type: "REMOTE_AUTH_TICKET",
                                ticket: data.ticket,
                                priv_jwk: JSON.stringify(privJwk)
                            }));
                        return;
                    } else if (op === "cancel") {
                        if (hbTimer) clearInterval(hbTimer);
                        ws.close(1000);
                        window.STEAMCORD_REMOTE_AUTH_ACTIVE = false;
                        if (window.STEAMCORD_WS?.readyState === 1)
                            window.STEAMCORD_WS.send(JSON.stringify({ type: "REMOTE_AUTH_FINGERPRINT", fingerprint: null }));
                        setTimeout(window.steamcordStartRemoteAuth, 3000);
                    }
                };
                ws.onerror = () => {};
                ws.onclose = (e) => {
                    if (hbTimer) clearInterval(hbTimer);
                    if (e.code !== 1000 && e.code !== 1001) {
                        window.STEAMCORD_REMOTE_AUTH_ACTIVE = false;
                        setTimeout(window.steamcordStartRemoteAuth, 3000);
                    }
                };
            } catch(e) {
                window.STEAMCORD_REMOTE_AUTH_ACTIVE = false;
                setTimeout(window.steamcordStartRemoteAuth, 5000);
            }
        };

        // Our custom remote-auth (Python ticket exchange) triggers Discord's hCaptcha,
        // especially on a flagged IP. In Vesktop we DON'T need it: the native Discord
        // login page shows its own QR, which startCanvasQRMirror() mirrors to the QAM —
        // scanning it logs Vesktop in natively, no ticket exchange, no CAPTCHA. So only
        // run the custom remote-auth in the CEF flow.
        if (!window.STEAMCORD_IS_VESKTOP) {
            Vencord.Webpack.onceReady.then(() => {
                if (!Vencord.Webpack.Common.UserStore.getCurrentUser()) window.steamcordStartRemoteAuth();
            });
            setInterval(() => {
                if (!Vencord.Webpack.Common.UserStore?.getCurrentUser?.() && !window.STEAMCORD_REMOTE_AUTH_ACTIVE)
                    window.steamcordStartRemoteAuth();
            }, 15000);
        }
    }
};

// In Vesktop, Vencord is already initialized and won't auto-start our (late-injected)
// plugin, so start it ourselves once Vencord/Webpack is ready. (In the CEF flow Vencord
// is injected fresh and calls start() itself.)
if (window.STEAMCORD_IS_VESKTOP && !window.__steamcord_started) {
    window.__steamcord_started = true;
    (function waitAndStart() {
        try {
            if (window.Vencord && window.Vencord.Webpack && window.Vencord.Webpack.Common) {
                window.Vencord.Plugins.plugins.Steamcord.start();
                console.log("[Steamcord] started in Vesktop");
                return;
            }
        } catch (e) { console.log("[Steamcord] vesktop start err " + e.message); }
        setTimeout(waitAndStart, 500);
    })();
}