# Steamcord

**Discord in Steam Gaming Mode** — a [Decky Loader](https://github.com/SteamDeckHomebrew/decky-loader) plugin for Steam Deck / Bazzite / SteamOS.

🌍 **Languages:** **English** · [Français](docs/README.fr.md) · [Deutsch](docs/README.de.md) · [Español](docs/README.es.md) · [Italiano](docs/README.it.md) · [Português](docs/README.pt.md) · [Nederlands](docs/README.nl.md) · [Polski](docs/README.pl.md) · [Русский](docs/README.ru.md)

> **Steamcord is an independent project.** It was originally inspired by
> [Deckcord](https://github.com/marios8543/Deckcord) (see Credits), but the codebase has been
> largely rewritten and now follows its own direction — it is not affiliated with or endorsed
> by that project.
>
> The plugin UI is fully translated into 9 languages and follows your SteamOS language automatically.

---

## How it works

Steamcord runs **[Vesktop](https://github.com/Vencord/Vesktop)** — a real, native Discord client — invisibly in the background, and drives it over the Chrome DevTools Protocol. The plugin injects a small client into it and exposes everything in the Steam **Quick Access Menu**.

Going native fixes the hard problems of the old hidden-browser approach: **your microphone and the voice audio work natively**, exactly as in the desktop Discord app — no capture hacks, no autoplay workarounds. Vesktop is launched (and installed if missing) automatically, stays logged in across reboots, and never needs a desktop window in Gaming Mode.

---

## Features

- **One Discord per Steam account (multi-session)** — Every Steam user on the machine gets their **own Discord profile**: switch the Steam account and Steamcord switches Discord automatically within seconds (the first time shows the QR login; after that each session is remembered). Nobody lands in someone else's Discord.
- **QR code login** — Scan a QR code with the Discord mobile app to log in instantly. On your phone: *Discord → Settings → Scan QR Code*, then aim at the code shown in the panel. No password typing on the Deck.
- **CAPTCHA solver, no Desktop Mode** — Discord sometimes puts a CAPTCHA on its login page; until it is solved no login ticket is issued and the QR code just keeps refreshing. Steamcord detects that and mirrors the login page in Gaming Mode so you can clear the challenge with the controller: D-pad moves the pointer, A clicks.
- **Unified navigation** — Top tabs **Voice / Text / ⚙️ Settings**, with a shared **Servers / DMs** switch underneath, so the same source toggle works for both voice and text.
- **Voice chat** — Join voice channels and hear everyone, with each member shown live (speaking ring, mute/deafen badges), a per-user volume slider (0–200%) **and a per-user local mute** (silence someone just for you, without them knowing). Mic and audio are native (Vesktop).
- **Private messages (DMs & Group DMs)** — Browse your conversations and start/join voice calls with friends directly from the Quick Access Menu. Active calls are highlighted.
- **Server voice browser** — See which voice channels have people in them (with member avatars) before joining.
- **Text chat — servers *and* DMs** — Read and reply to a server channel **or a private conversation** from the QAM (full-width input, Steam keyboard opens automatically). **Image attachments show as thumbnails** (loaded only while the channel is open) and **links open in the Steam Gaming Mode browser**. Auto-scrolls to the latest message.
- **Discord status on your name** — Your **clickable username** at the top shows your current status; tap it to change it. Optional auto-sync makes Discord **follow your Steam status** in the background; picking one by hand switches back to manual.
- **Audio device selection** — From Settings, choose the **output (Discord sound)** and **input (microphone)** device — *Auto (system default)* or a specific device, e.g. send Discord audio to your **headset only** while games stay on HDMI.
- **Mute / Deafen / Disconnect** — One-tap voice controls from the QAM, with Discord's own native sound cues (mute/unmute, deafen/undeafen, disconnect, participants joining/leaving).
- **Soundboard** — Browse and play the default sounds, the current server's sounds, and (with Nitro) every other server's sounds, right from the voice call view. You hear your own sounds too, just like the real client.
- **Screen share** — Share your whole screen to a voice channel (Go Live). Works natively in Desktop / Big Picture, **and now natively in Gaming Mode too**: gamescope ships no screen-capture portal (which is why the normal Go Live used to be a black screen there), so the plugin runs its own tiny ScreenCast portal (`portal_shim.py`) that hands Chromium the gamescope PipeWire node — the same node Steam's built-in Game Recording uses. Real Go Live, full resolution, game audio via venmic, no kernel module, nothing written to the rootfs (survives SteamOS A/B updates). The legacy paths remain as fallbacks: the local GStreamer WebRTC relay (automatic when no portal answers) and the **"Share screen (game mode)"** virtual-camera button (v4l2loopback, needs one-time setup). The Go Live thumbnail in the QAM is **removed for now** — a live thumbnail needs a second PipeWire consumer on the gamescope node, which starves its buffer pool and freezes the picture for your viewers. The LIVE badge still tells you the share is running, and sharing itself is unaffected.
- **Share game audio** — Stream your game's sound into the voice channel **along with your voice**. Two mix sliders (🎙️ voice / 🎮 game) control what the others hear, while you keep hearing the game normally — and it works even **without a physical microphone** (the plugin creates a virtual *Steamcord Mic* input).
- **In-game notifications** — Incoming DM calls and pings appear as **native Steam notifications (popup + sound)**, respecting your Discord status (silenced when invisible / do-not-disturb).
- **🕹️ Controller voice shortcut** — Capture **any button combo on your controller** and bind it to **mute toggle** or **push-to-talk**. It works globally in-game, even with the QAM closed (set it up in the Settings tab).
- **Share screenshots** — Send a Steam screenshot straight into the conversation you have open.
- **[Vencord](https://vencord.dev/)** is built into Vesktop, giving access to its plugin ecosystem.
- 🐧 **Compatibility** — we actively work to support every OS that can run Steam in Gaming Mode / Big Picture (Linux for now): portable detection, vendored Python deps, no distro-specific assumptions. Per-distro package notes: [docs/OS-NOTES.md](docs/OS-NOTES.md).

---

## 📸 Screenshots

<p align="center">
  <img src="docs/img/steamcord-servers.jpg" width="49%" alt="Discord servers"/>
  <img src="docs/img/steamcord-dm-chat.jpg" width="49%" alt="Direct messages"/>
</p>
<p align="center">
  <img src="docs/img/steamcord-voice-call.jpg" width="49%" alt="Voice call"/>
  <img src="docs/img/steamcord-voice-live.jpg" width="49%" alt="Screen share live"/>
</p>

## Installation

> **Not yet on the Decky Store.** Install manually via Developer Mode.

1. Enable **Developer Mode** in Decky → General settings
2. Go to **Developer** in Decky settings
3. Install from URL:
   `https://github.com/Necrosiak/Steamcord/releases/latest/download/Steamcord.zip`

> **A note on automatic updates.** Decky owns the plugin's top-level directory,
> so the built-in updater can rewrite existing files but cannot create new ones.
> A release that adds a file at the top level therefore has to be installed the
> normal way — *Install plugin from URL*, above — rather than through the
> automatic update. The release notes say so whenever that is the case.

Vesktop is installed and launched automatically by the plugin the first time it runs. Just log in once (QR code, or Vesktop in Desktop Mode) and you stay logged in.

Nothing else is required: the Python dependencies are vendored, and the handful of system tools some features shell out to (`pw-dump`, `pactl`, `ffmpeg`, `gamescopectl`) are optional — each one only costs the feature it powers, and the backend logs a `[deps]` line at startup naming any that are missing. See **[docs/OS-NOTES.md](docs/OS-NOTES.md)** for the full table and per-distro packages, including NixOS, Gentoo, Alpine and Void.

### Screen share
Screen sharing works out of the box — the plugin auto-installs its Python dependency (aiohttp) for the system Python on first run. GStreamer is provided by the system.

### Keyboard / mouse push-to-talk outside SteamOS
Binding the voice shortcut to a **controller** button works everywhere. Binding it to a **keyboard key or mouse button** requires the plugin to read `/dev/input/event*`, which needs a `uaccess` ACL — and systemd grants that to **joysticks only** (`70-uaccess.rules`: `ENV{ID_INPUT_JOYSTICK}`). SteamOS ships an extra rule covering input devices; most other distributions do not.

Measured on Bazzite: a USB wireless mouse returned `EACCES` on all five of its nodes, and a keyboard was readable only because an unrelated RGB-lighting rule happened to tag it. The shortcut panel tells you when a device is present but unreadable, instead of silently offering nothing.

To opt in, as root:

```
# /etc/udev/rules.d/70-input-uaccess.rules
SUBSYSTEM=="input", ENV{ID_INPUT_KEYBOARD}=="1", TAG+="uaccess"
SUBSYSTEM=="input", ENV{ID_INPUT_MOUSE}=="1", TAG+="uaccess"
```

```
sudo udevadm control --reload-rules && sudo udevadm trigger --subsystem-match=input
```

⚠️ Know what this costs: `uaccess` lets **any** process running as your user read every keystroke on the machine, in any window — not just this plugin. It is the same trade SteamOS makes on the Deck, which is reasonable on a single-user games console and much less so on a machine you also work on. Delete the file to revert.

---

## Build from source

```bash
git clone https://github.com/Necrosiak/Steamcord
cd Steamcord
pnpm install
pnpm run build
# copy dist/, main.py, defaults/, plugin.json, package.json to ~/homebrew/plugins/Steamcord/
sudo systemctl restart plugin_loader
```

---

## 🐛 Issues & ideas — don't hesitate!

Found a bug, something misbehaving on your distro, or missing a feature?
**Please open an [issue](https://github.com/Necrosiak/Steamcord/issues)** —
every report directly shapes what gets built next. Include if you can:

- your distro & version (Bazzite 42, CachyOS, Ubuntu 24.04…) and how Steam runs (Gaming Mode / Big Picture / desktop)
- the plugin version (Settings → Update) and whether Vesktop is flatpak or native
- what you did, what you expected, what happened instead
- logs: `~/homebrew/logs/Steamcord/` and `journalctl -b | grep -i steamcord`

Feature requests and "it works!" reports on unusual setups are just as valuable.

> **The UI for the newer features is not final.** The in-game voice and POV
> overlays, the fullscreen multi-POV grid and the quick-reply panel are recent
> additions and their layout, controls and defaults are still open to change.
> If something feels awkward or you'd arrange it differently, please say so in
> an issue — the same goes for anything added from here on. Suggestions shape
> these as much as bug reports do.

## Credits

- Original project: [marios8543/Deckcord](https://github.com/marios8543/Deckcord) — architecture, BrowserView setup, GStreamer screen share
- [@aagaming](https://github.com/AAGaming00) — mic support via the SteamClient tab (WebRTC relay)
- [@Epictek](https://github.com/Epictek) — QR Code login foundation
- [@jessebofill](https://github.com/jessebofill) — Steam menu patching code
- [Vesktop / Vencord](https://github.com/Vencord/Vesktop) — the native Discord client Steamcord drives

### Code contributors

- [@azizzidi](https://github.com/azizzidi) — **native Go Live in Gaming Mode** via the gamescope ScreenCast portal shim ([#10](https://github.com/Necrosiak/Steamcord/pull/10), landed in v1.15.0)

### Community bug hunters

Steamcord is largely shaped by the people who report things. The full list —
who found what, and which release it landed in — lives in
**[CREDITS.md](CREDITS.md)**.

## AI disclaimer

AI was used in the making of this project — for reverse engineering, development and documentation. It was **not** used for any art or creative writing. Everything released publicly is reviewed by a human, and the results are my responsibility. If that is not something you are comfortable with, now you know.
