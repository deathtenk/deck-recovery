from discord_client.remote_auth import RemoteAuth
from discord_client.store_access import StoreAccess, User
from aiohttp.web import WebSocketResponse  # type: ignore
from asyncio import Task, create_task, Event, Queue
from json import loads
from aiohttp import WSMsgType  # type: ignore
from decky import emit  # type: ignore
import logging


logger = logging.getLogger(__name__)


class EventHandler:
    def __init__(self) -> None:
        self.event_handlers = {
            "LOADED": self._loaded,
            "CONNECTION_OPEN": self._logged_in,
            "REMOTE_AUTH_FINGERPRINT": self._remote_auth_fingerprint,
            "REMOTE_AUTH_QR_SVG": self._remote_auth_qr_svg,
            "REMOTE_AUTH_SCANNED": self._remote_auth_scanned,
            "REMOTE_AUTH_CAPTCHA": self._remote_auth_captcha,
            "REMOTE_AUTH_TICKET": self._remote_auth_ticket,
            "STREAM_START": self._stream_start,
            "STREAM_STOP": self._stream_stop,
            "CONNECTION_CLOSED": self._logout,
            "LOGOUT": self._logout,
            "VOICE_STATE_UPDATES": self._voice_state_updates,
            "VOICE_CHANNEL_SELECT": self._voice_channel_select,
            "AUDIO_TOGGLE_SELF_MUTE": self._toggle_mute,
            "AUDIO_TOGGLE_SELF_DEAF": self._toggle_deaf,
            "RPC_NOTIFICATION_CREATE": self._rpc_notification,
            "SPEAKING": self._speaking,
            "$MIC_WEBRTC": self._mic_webrtc,
            "$VIDEO_WEBRTC": self._video_webrtc,
            "CALL_RING": self._call_ring,
            "TYPING_START": self._typing_start,
            "CHAT_MESSAGE": self._chat_message,
        }
        self.loaded = False
        self.logged_in = False
        self.me = User({"id": "", "username": "", "discriminator": None, "avatar": ""})
        self.api = StoreAccess()
        self.ws = None
        self.vc_channel_id = None
        self.api._channel_name = None
        self.api._guild_name = None
        self.vc_members = {}
        # IDs des participants qui partagent (Go Live). Découplé de vc_members pour
        # éviter une race : STREAM_START peut arriver avant que la liste vocale soit
        # peuplée (ou les membres sont reconstruits à chaque VOICE_STATE_UPDATES).
        self.streaming_users = set()
        self._qr_scanned = False  # QR scanné, en attente de validation sur le téléphone
        # Discord sert un CAPTCHA sur la page de login (#37). Attribut RÉEL et non
        # plus un getattr avec valeur par défaut : il n'était posé que sur le chemin
        # remote-auth maison — désactivé sous Vesktop — donc il n'existait jamais.
        self._captcha_needed = False
        self.state_changed_event = Event()
        # Salon ouvert dans le chat plein écran (posé par set_fullscreen_channel) :
        # on n'émet PAS de notif de MESSAGE pour ce salon tant qu'il est lu (#21).
        self.fullscreen_channel = ""
        # FILE dédiée aux notifications. Deux raisons de ne pas repasser par un
        # Event + un slot unique :
        # 1. state_changed_event était partagé avec yield_new_state → sous events
        #    rapprochés (arrivée d'un participant : VOICE_CHANNEL_SELECT +
        #    VOICE_STATE_UPDATES + reconcile en rafale) un consommateur clear()
        #    l'event posé pour l'autre → une mise à jour d'ÉTAT était AVALÉE.
        # 2. Le slot unique qui a remplacé ça perdait les notifs en RAFALE : le
        #    dispatch CDP (main.py) dure plusieurs centaines de ms, et toute notif
        #    arrivée pendant écrasait la précédente puis était effacée par le
        #    `self.notification = None` d'après-yield. 2 messages coup sur coup =
        #    1 seul toast. Une Queue conserve l'ordre et ne perd rien.
        self.notifications: Queue = Queue()
        self.remote_auth = RemoteAuth()
        # Posé par Plugin : ré-assertion de réglages (ex. prefs micro) à chaque
        # login du client — la persistance Discord seule ne suffit pas (#14).
        self.on_logged_in = None

    def build_state_dict(self):
        return {
            "loaded": self.loaded,
            "logged_in": self.logged_in,
            "me": self.me.to_dict(),
            "vc": self._build_vc_dict(),
            "qr_login": self.remote_auth.qr_b64,
            "qr_scanned": self._qr_scanned,
            "captcha_needed": self._captcha_needed,
        }

    def _build_vc_dict(self):
        if self.vc_channel_id is None:
            return None

        users = list(self.vc_members.values())
        # Garantir que SOI est toujours présent dans la liste affichée. self est
        # ignoré dans _voice_state_updates (présence multi-appareils) ET dans la
        # réconciliation → un rebuild mal timé pouvait l'omettre → l'utilisateur ne
        # se voyait pas alors qu'il est en vocal. On l'injecte en tête si absent.
        if self.me.id and not any(u.id == self.me.id for u in users):
            users = [self.me] + users
        # Reflète l'état de partage courant indépendamment de l'ordre des events.
        for user in users:
            user.is_live = user.id in self.streaming_users

        return {
            "channel_id": self.vc_channel_id,
            "channel_name": self.api._channel_name,
            "guild_name": self.api._guild_name,
            "users": [u.to_dict() for u in users],
        }

    async def send_client(self, payload):
        """Envoi vers le client injecté, avec échec PROPRE si le ws est mort ou
        en cours de fermeture (bascule Bureau↔gamemode : Vesktop meurt, re-init
        ~2 min). Le code stable `discord_reconnecting` est traduit côté frontend
        au lieu d'afficher « Cannot write to closing transport » brut."""
        if self.ws is None or self.ws.closed:
            raise Exception("discord_reconnecting")
        try:
            await self.ws.send_json(payload)
        except Exception:
            raise Exception("discord_reconnecting")

    async def _play_sound(self, name):
        # Sons natifs Discord (mute/deafen/disconnect/user_join/user_leave —
        # demande user). Best-effort : la sonnerie ne doit JAMAIS faire échouer
        # l'action réelle (toggle mute, mise à jour de la liste des membres…)
        # qui l'a déclenchée, donc on avale toute erreur (ws fermé pendant une
        # reconnexion, client pas encore prêt, etc.).
        try:
            await self.send_client({"type": "$play_sound", "name": name})
        except Exception:
            pass

    async def toggle_mute(self, act=False):
        if act:
            # ON N'ENVOIE QUE LA COMMANDE — surtout PAS de lecture ni de push ici.
            # Discord ré-émet TOUJOURS AUDIO_TOGGLE_SELF_MUTE en écho (prouvé via
            # CDP) → `_toggle_mute` met à jour depuis la VÉRITÉ et pousse l'état =
            # SOURCE UNIQUE. Si on pousse EN PLUS ici, on émet un 2e état : soit
            # optimiste aveugle (base périmée), soit un get_media() racé (le toggle
            # n'est pas encore appliqué quand on lit) → valeur ≠ écho → le bouton
            # « clignote » (part et revient). Un seul push (l'écho, settled) = zéro
            # flicker.
            await self.send_client({"type": "AUDIO_TOGGLE_SELF_MUTE", "context": "default", "syncRemote": False})
            return
        self.me.is_muted = not self.me.is_muted
        self.state_changed_event.set()

    async def toggle_deafen(self, act=False):
        if act:
            # Idem mute : l'écho AUDIO_TOGGLE_SELF_DEAF (_toggle_deaf) est la source
            # unique. On n'envoie que la commande pour ne pas pousser un 2e état.
            await self.send_client({"type": "AUDIO_TOGGLE_SELF_DEAF", "context": "default"})
            return
        self.me.is_deafened = not self.me.is_deafened
        self.state_changed_event.set()

    async def disconnect_vc(self):
        await self.send_client({"type": "VOICE_CHANNEL_SELECT", "channelId": None, "guildId": None})

    async def yield_new_state(self):
        while True:
            await self.state_changed_event.wait()
            self.state_changed_event.clear()
            yield self.build_state_dict()

    async def yield_notification(self):
        while True:
            yield await self.notifications.get()

    async def main(self, ws):
        logger.info("Received WS Connection. Starting event processing loop")
        self.ws = ws
        self.api.ws = ws
        async for msg in self.ws:
            if msg.type == WSMsgType.TEXT:
                self._process_event(loads(msg.data))
            elif msg.type == WSMsgType.ERROR:
                print('ws connection closed with exception %s' % self.ws.exception())

    def _process_event(self, data):
        if data["type"] == "$ping":
            return
        if data["type"] == "$pov_chunk":
            # Fragments H264/fMP4 (MediaRecorder client) pour l'overlay POV,
            # routés directement au hook du plugin sans passer par la machinerie
            # d'events (pas un event Discord).
            cb = getattr(self, "on_pov_chunk", None)
            if cb:
                try:
                    cb(data)
                except Exception as e:
                    logger.debug(f"pov chunk hook failed: {e!r}")
            return
        if data["type"] == "$diag":
            logger.info(f"[clientdiag] {data.get('m')}")
            return
        if data["type"] == "$steamcord_request" and "increment" in data:
            self.api._set_result(data["increment"], data["result"])
            return
        if data["type"] in self.event_handlers:
            callback = self.event_handlers[data["type"]]
            logger.info(f"Handling event: {data['type']}")
            #print(dumps(data, indent=2)+"\n\n")
        else:
            return
        def _(future: Task):
            self.state_changed_event.set()
            e = future.exception()
            if e:
                # logger, PAS print : l'exception d'un handler doit être visible
                # dans le log du plugin (une notif perdue se diagnostiquait à
                # l'aveugle avant).
                logger.warning(f"Exception during handling of {data['type']} event: {e!r}")

        create_task(callback(data)).add_done_callback(_)

    async def _loaded(self, data):
        self.loaded = True
        if not self.logged_in:
            self.remote_auth.start(self.state_changed_event.set)

    async def _logged_in(self, data):
        self.logged_in = True
        self._qr_scanned = False
        self._captcha_needed = False
        self.remote_auth.stop()
        user_data = data.get("user") if isinstance(data, dict) else None
        if not user_data or not user_data.get("id"):
            return
        self.me = User(user_data)
        s = await self.api.get_media()
        self.me.is_muted = s["mute"]
        self.me.is_deafened = s["deaf"]
        self.me.is_live = s["live"]
        if self.on_logged_in:
            try:
                await self.on_logged_in()
            except Exception as e:
                logger.warning(f"on_logged_in hook failed: {e!r}")

    async def _logout(self, data):
        self.logged_in = False
        self._qr_scanned = False
        self._captcha_needed = False
        self.me = User({"id": "", "username": "", "discriminator": None, "avatar": ""})
        # Purger l'état d'appel pour ne pas laisser un faux « en vocal » au QAM.
        self.vc_channel_id = None
        self.vc_members = {}
        self.streaming_users = set()
        self.remote_auth.start(self.state_changed_event.set)

    async def _voice_channel_select(self, data):
        new_id = data["channelId"]
        # Re-sélection du MÊME salon (events VOICE_CHANNEL_SELECT dupliqués : poll
        # client toutes les 2s + dispatch Discord natif + re-handshake) → NE PAS
        # reconstruire vc_members. Le rebuild via get_voice_states peut renvoyer []
        # transitoirement (store pas prêt pendant une reconnexion) → la liste était
        # VIDÉE → le participant disparaissait (ou réapparaissait greyé). La
        # réconciliation 2s maintient déjà l'état à jour ; on ne rebuild qu'au VRAI
        # changement de salon (ou si la liste a été perdue).
        if new_id is not None and new_id == self.vc_channel_id and self.vc_members:
            return
        old_id = self.vc_channel_id
        self.vc_channel_id = new_id
        if self.vc_channel_id is None:
            self.vc_members = {}
            self.api._channel_name = None
            self.api._guild_name = None
            # Pas de son "connect" natif chez Discord (le manifest du soundpack
            # n'en a pas — seul "disconnect" existe) : on ne joue donc qu'à la
            # VRAIE sortie d'un salon (old_id non nul), jamais au démarrage
            # (old_id déjà None) ni à une simple re-sélection du même salon.
            if old_id is not None:
                await self._play_sound("disconnect")
            return

        channel = await self.api.get_channel(self.vc_channel_id)
        if not isinstance(channel, dict):
            channel = {}
        guild_id = channel.get("guild_id")

        if guild_id:
            # Guild voice channel
            self.api._channel_name = channel.get("name") or "Salon vocal"
            guild = await self.api.get_guild(guild_id)
            self.api._guild_name = guild.get("name") if isinstance(guild, dict) else None
        else:
            # DM (type 1) or Group DM (type 3) — no guild
            name = channel.get("name")
            if not name:
                # 1:1 DM: derive the name from the recipient
                recips = channel.get("rawRecipients") or channel.get("recipients") or []
                if recips:
                    r0 = recips[0]
                    if isinstance(r0, dict):
                        name = r0.get("global_name") or r0.get("username")
                    elif isinstance(r0, str):
                        u = await self.api.get_user(r0)
                        name = u.get("username") if isinstance(u, dict) else None
            # Leave names neutral — the frontend localizes the "private message"
            # label so it follows the SteamOS language.
            self.api._channel_name = name or None
            self.api._guild_name = None

        # Load existing members already in the channel
        self.vc_members = {}
        try:
            voice_states = await self.api.get_voice_states(self.vc_channel_id)
            if isinstance(voice_states, list):
                for vs in voice_states:
                    user_id = vs.get("userId")
                    if not user_id:
                        continue
                    user = User({"id": user_id, "username": "", "discriminator": None, "avatar": ""})
                    user.is_muted = vs.get("mute", False)
                    user.is_deafened = vs.get("deaf", False)
                    user.is_video = vs.get("video", False)
                    await user.populate(self.api)
                    self.vc_members[user_id] = user
        except Exception as e:
            logger.error(f"Failed to load voice states: {e}")

    async def _voice_state_updates(self, data):
        for vs in data.get("voiceStates", []):
            user_id = vs["userId"]
            channel_id = vs.get("channelId")

            # Skip our OWN voice state here: VOICE_STATE_UPDATES reflects ACCOUNT-level
            # presence, so it also reports voice connections on OTHER devices (PC, phone).
            # Reconciling from it made the BC show "in call" while we were actually
            # connected elsewhere. The JS poller tracks the LOCAL connection via
            # SelectedChannelStore.getVoiceChannelId() and emits VOICE_CHANNEL_SELECT —
            # that is the single source of truth for "in call on THIS machine".
            if user_id == self.me.id:
                continue

            # On n'est dans AUCUN salon (vc_channel_id=None) : ignorer entièrement.
            # Sans cette garde, un AMI qui quitte un vocal ailleurs (channelId=null
            # côté lui aussi) matchait `channel_id == self.vc_channel_id` (None==None)
            # et faisait jouer un son "connexion" pour du monde sans rapport avec
            # nous — régression découverte le 20/07 en testant les sons natifs.
            if self.vc_channel_id is None:
                continue

            if channel_id == self.vc_channel_id:
                # `existed` AVANT la création : un membre qui ARRIVE caméra allumée
                # (ou le resync) ne doit pas déclencher le toast « a allumé sa
                # caméra » — seule la vraie TRANSITION off→on d'un membre déjà
                # présent compte.
                existed = user_id in self.vc_members
                if not existed:
                    user = User({"id": user_id, "username": "", "discriminator": None, "avatar": ""})
                    await user.populate(self.api)
                    self.vc_members[user_id] = user
                    # Un membre existant déjà présent quand ON rejoint est peuplé par
                    # _voice_channel_select (get_voice_states), PAS ici → ce branch
                    # "not existed" n'est atteint que pour une VRAIE arrivée en
                    # temps réel dans le salon où on est déjà connecté.
                    await self._play_sound("user_join")
                u = self.vc_members[user_id]
                # Lecture défensive multi-casse (camelCase store / snake_case gateway)
                # pour ne jamais rester coincé sur un faux « muet ».
                def _flag(*keys):
                    return any(vs.get(k) for k in keys)
                new_mute = _flag("mute", "selfMute", "self_mute")
                new_deaf = _flag("deaf", "selfDeaf", "self_deaf")
                new_video = _flag("video", "selfVideo", "self_video")
                if existed and new_video and not u.is_video:
                    self._notify_video_event(u, "camera_start")
                u.is_muted = new_mute
                u.is_deafened = new_deaf
                u.is_video = new_video
            elif user_id in self.vc_members:
                del self.vc_members[user_id]
                await self._play_sound("user_leave")

    # Échos de Discord (AUDIO_TOGGLE_SELF_MUTE/DEAF). Ces events arrivent AUSSI quand
    # c'est NOUS qui avons déclenché le toggle (Discord ré-émet l'event qu'on lui a
    # envoyé) → re-toggler ici annulait notre action (« ça se démute direct »). On LIT
    # l'état réel et on le FIXE (idempotent) : marche pour nos toggles ET les externes.
    async def _toggle_mute(self, data):
        s = await self.api.get_media()
        self.me.is_muted = s["mute"]
        self.me.is_deafened = s["deaf"]
        await self._play_sound("mute" if s["mute"] else "unmute")

    async def _toggle_deaf(self, data):
        s = await self.api.get_media()
        self.me.is_muted = s["mute"]
        self.me.is_deafened = s["deaf"]
        await self._play_sound("deafen" if s["deaf"] else "undeafen")

    async def _rpc_notification(self, data):
        # L'event NOTIFICATION_CREATE de Discord porte title/body/icon_url à la
        # RACINE ; l'ancien chemin embeds[0] ne vaut que pour certains messages
        # (et levait IndexError sur un message texte sans embed → notif perdue,
        # silencieusement car l'exception du handler partait dans print()).
        msg = data.get("message") or {}
        author = msg.get("author") or {}
        embeds = msg.get("embeds") or []
        emb_author = (embeds[0].get("author") or {}) if embeds else {}
        title = (data.get("title") or emb_author.get("name")
                 or author.get("global_name") or author.get("username") or "Discord")
        body = (data.get("body")
                or (embeds[0].get("description") if embeds else None)
                or msg.get("content") or "")
        # icon = avatar Discord de l'expéditeur : icon_url de l'event si présent,
        # sinon reconstruit depuis message.author (id + hash d'avatar CDN).
        icon = data.get("icon_url") or ""
        if not icon and author.get("id") and author.get("avatar"):
            icon = f"https://cdn.discordapp.com/avatars/{author['id']}/{author['avatar']}.png?size=64"
        # MP ou chan de serveur : enrichissement client (__sc_*) si présent, sinon
        # fallback sans client — un message de serveur porte un guild_id, pas un MP
        # (couvre un Vesktop qui tourne encore avec l'ancien client injecté).
        dm = bool(data.get("__sc_dm")) if "__sc_dm" in data else not msg.get("guild_id")
        if not dm:
            chan = data.get("__sc_channel") or ""
            guild = data.get("__sc_guild") or ""
            ctx = ", ".join(x for x in (f"#{chan}" if chan else "", guild) if x)
            if ctx:
                title = f"{title} ({ctx})"
        chan_id = str(data.get("channelId") or msg.get("channel_id") or "")
        # Salon en cours de lecture plein écran → on saute la notif de message
        # (David #21). Ne concerne QUE les messages : les appels (_call_ring) et
        # les events stream/caméra (_notify_video_event) passent par d'autres
        # handlers et ne sont donc pas touchés.
        if chan_id and chan_id == self.fullscreen_channel:
            logger.info(f"notification supprimée (salon {chan_id} ouvert en plein écran)")
            return
        notification = {"title": title, "body": body, "icon": icon,
                        "kind": "dm" if dm else "group",
                        "channel_id": chan_id}
        logger.info(f"notification built: kind={notification['kind']} "
                    f"title={title!r} icon={'oui' if icon else 'non'} "
                    f"enrichi={'__sc_dm' in data}")
        self.notifications.put_nowait(notification)

    async def _call_ring(self, data):
        # Incoming DM call → notify. The frontend localizes the title via kind="call".
        # channel_id lets a click on the notification answer the call directly
        # (dm_call(channel_id, join_existing=True) — same call already ringing).
        self.notifications.put_nowait(
            {"title": "", "body": data.get("caller") or "Discord",
             "kind": "call", "icon": data.get("caller_avatar") or "",
             "channel_id": data.get("channel_id") or ""})

    async def _typing_start(self, data):
        # "X is typing…" for whichever conversation is open in the fullscreen
        # chat — pushed live via Decky's emit (same channel as "state"), no
        # polling needed. The frontend filters by channel_id itself and
        # auto-clears after a few seconds (Discord has no "stopped typing"
        # event, only repeated TYPING_START while someone keeps typing).
        await emit("typing", {
            "channel_id": str(data.get("channel_id") or ""),
            "username": data.get("username") or "",
        })

    async def _chat_message(self, data):
        # Live chat push for the channel currently watched by the QAM/fullscreen
        # chat (the Vesktop tab only forwards MESSAGE_* events for the watched
        # channel, see $watch_channel). op = create / update / delete /
        # reaction_add / reaction_remove; the frontend patches its local list —
        # messages arrive the second they are sent instead of on the next poll.
        await emit("chat_message", {
            "op": data.get("op") or "",
            "channel_id": str(data.get("channel_id") or ""),
            "message": data.get("message"),
            "message_id": str(data.get("message_id") or ""),
            "emoji": data.get("emoji") or "",
            "me": bool(data.get("me")),
        })

    async def _mic_webrtc(self, data):
        # Relay the Discord tab's mic offer/ICE to the SharedJSContext frontend,
        # which captures the REAL microphone and answers. No handler existed before
        # — the offer was silently dropped, so the mic peer connection stayed in
        # "new" and others could never hear the user.
        payload = {}
        if "offer" in data:
            payload["offer"] = data["offer"]
        if "ice" in data:
            payload["ice"] = data["ice"]
        if payload:
            await emit("webrtc", payload)

    async def _video_webrtc(self, data):
        # Reverse video relay: the Discord tab offers a remote participant's video
        # stream; forward the offer/ICE to the QAM frontend, which answers and renders
        # it in that user's block. Correlated by userId.
        payload = {"userId": data.get("userId")}
        if "offer" in data:
            payload["offer"] = data["offer"]
        if "ice" in data:
            payload["ice"] = data["ice"]
        # meta: [{mid, kind}] — lets the QAM label each track (screen vs camera).
        if "meta" in data:
            payload["meta"] = data["meta"]
        await emit("video_webrtc", payload)

    async def _speaking(self, data):
        user_id = data.get("userId") or data.get("user_id")
        speaking = data.get("speakingFlags", 0) > 0
        if user_id == self.me.id:
            self.me.is_speaking = speaking
        elif user_id in self.vc_members:
            self.vc_members[user_id].is_speaking = speaking

    async def _remote_auth_fingerprint(self, data):
        fingerprint = data.get("fingerprint")
        if fingerprint:
            from discord_client.remote_auth import _make_qr_b64
            self.remote_auth.qr_b64 = _make_qr_b64(f"https://discord.com/ra/{fingerprint}")
        else:
            self.remote_auth.qr_b64 = None

    async def _remote_auth_qr_svg(self, data):
        self.remote_auth.qr_b64 = data.get("svg_b64")
        if data.get("svg_b64"):
            self._qr_scanned = False  # un QR visible = pas encore scanné

    async def _remote_auth_scanned(self, data):
        # QR scanné → Discord attend la validation sur le téléphone.
        self._qr_scanned = bool(data.get("scanned"))

    async def _remote_auth_captcha(self, data):
        # Défi hCaptcha/Arkose planté sur la page de login par Discord (#37).
        # Tant qu'il n'est pas résolu, Discord n'émet aucun ticket : le QR tourne
        # en boucle pour rien. Le QAM affiche le miroir de la page pour le résoudre
        # à la manette, sans repasser en mode Bureau.
        self._captcha_needed = bool(data.get("captcha"))

    async def _remote_auth_ticket(self, data):
        from discord_client.remote_auth import exchange_ticket
        ticket = data.get("ticket")
        priv_jwk = data.get("priv_jwk")
        if not ticket or not priv_jwk:
            return
        token, captcha = await exchange_ticket(ticket, priv_jwk)
        if token:
            self._captcha_needed = False
            await self.send_client({"type": "$login_token", "token": token})
        else:
            self.remote_auth.qr_b64 = None
            if captcha:
                self._captcha_needed = True

    def _notify_video_event(self, user, kind):
        # Toast SteamOS quand quelqu'un du vocal lance un partage/sa caméra : sans
        # ça, QAM fermé, on ne savait jamais qu'une vidéo avait démarré (Discord
        # ne notifie pas ces events lui-même, c'est de l'UI in-app). Le frontend
        # localise le corps via kind ; body = pseudo (persona du toast).
        icon = user.avatar or ""
        if icon and not icon.startswith("http"):
            icon = f"https://cdn.discordapp.com/avatars/{user.id}/{icon}.png?size=64"
        self.notifications.put_nowait(
            {"title": "", "body": user.name or "", "kind": kind, "icon": icon})

    def reset_stream_state(self):
        """Oublier tous les Go Live connus. À appeler quand la page Discord est
        repartie de zéro (Vesktop tué/relancé).

        Sans ça, un stream lancé AVANT le redémarrage restait « en direct » pour
        toujours : la nouvelle page démarre avec un ensemble de streams VIDE,
        donc son poll de resynchronisation ne peut émettre aucun STREAM_STOP pour
        une clé qu'elle n'a jamais vue — et le QAM continuait d'afficher
        « Arrêter le Go Live » alors que plus rien ne streamait. Vécu le 31/08 :
        Vesktop s'est terminé 9 s après un Go Live, le bouton mentait, et côté
        interlocuteur il n'y avait rien du tout. Le poll du client ré-émettra un
        STREAM_START pour tout partage réellement actif au tour suivant.
        """
        self.streaming_users = set()
        if self.me is not None:
            self.me.is_live = False
        for user in self.vc_members.values():
            user.is_live = False

    async def _stream_start(self, data):
        # Reflect Go Live state in the QAM. Discord emits STREAM_START for any
        # participant; the streamer is the last segment of the stream key
        # (call:channelId:ownerId / guild:guildId:channelId:ownerId).
        stream_key = data.get("streamKey", "") or ""
        owner_id = stream_key.split(":")[-1] if stream_key else None
        # `already` d'ABORD : le poll du client ré-émet des STREAM_START
        # synthétiques au resync — ne notifier que le VRAI démarrage.
        already = owner_id in self.streaming_users if owner_id else True
        if owner_id:
            self.streaming_users.add(owner_id)
        if (self.me.id and self.me.id in stream_key) or not stream_key:
            self.me.is_live = True
        elif owner_id and not already:
            member = self.vc_members.get(owner_id)
            if member:
                self._notify_video_event(member, "stream_start")

    async def _stream_stop(self, data):
        stream_key = data.get("streamKey", "") or ""
        owner_id = stream_key.split(":")[-1] if stream_key else None
        if owner_id:
            self.streaming_users.discard(owner_id)
        if (self.me.id and self.me.id in stream_key) or not stream_key:
            self.me.is_live = False
            # ⚠️ NE PAS relâcher les sessions portail ici (essayé le 01/09,
            # retiré le jour même). Ça FONCTIONNE — les 3 sessions se ferment
            # enfin au lieu de fuir — mais `close_all` est un mécanisme de
            # DERNIER RECOURS : à l'origine il n'était appelé qu'APRÈS un échec
            # du getDisplayMedia natif, donc sur des sessions forcément
            # orphelines, et avec 0,5 s d'attente pour laisser Chromium digérer
            # le `Closed`. Dans le chemin normal, Discord émet deux STREAM_STOP
            # à 5 s d'écart → deux `close_all` pendant que Chromium démonte
            # encore son flux ; le Go Live suivant a pendu à l'acquisition et
            # Vesktop est mort 13 s plus tard. Corrélation, pas preuve (un même
            # crash s'était produit plus tôt le même jour sans ce code) — mais
            # la fuite de sessions n'est qu'un facteur AGGRAVANT du gel, pas sa
            # cause, et ça ne vaut pas ce risque. À reprendre proprement :
            # débouncer, ne cibler que les sessions de CE partage, et attendre
            # que Chromium ait lâché ses fds. Cf. vesktop.release_portal_sessions.
